import { Shield } from 'lucide-react';

export function Logo({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative">
        <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center shadow-sm">
          <Shield className="w-5 h-5 text-white" strokeWidth={2.5} />
        </div>
        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border-2 border-white" />
      </div>
      <div className="flex flex-col leading-none">
        <span className="text-lg font-bold text-gray-900 tracking-tight">SafeZone</span>
        <span className="text-[10px] font-medium text-blue-600 tracking-wider">AI</span>
      </div>
    </div>
  );
}
