import type { Incident, Language } from '@/types';
import { SeverityBadge, StatusBadge } from '@/components/Badges';
import { formatRelativeTime } from '@/lib/format';
import { Construction, Waves, Flame, ShieldAlert, Zap, Biohazard, Building2, Dog, AlertTriangle, MapPin } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const categoryIcons: Record<string, LucideIcon> = {
  Construction,
  Waves,
  Flame,
  ShieldAlert,
  Zap,
  Biohazard,
  Building2,
  Dog,
  AlertTriangle,
};

export function IncidentCard({
  incident,
  language,
  onClick,
}: {
  incident: Incident;
  language: Language;
  onClick?: () => void;
}) {
  const categoryLabel =
    language === 'te' ? incident.category?.label_te : incident.category?.label_en;
  const iconName = incident.category?.icon ?? 'AlertTriangle';
  const CategoryIcon = categoryIcons[iconName] ?? AlertTriangle;

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md hover:border-blue-200 transition-all group focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
          <CategoryIcon className="w-5 h-5 text-blue-600" aria-hidden="true" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1.5">
            <span className="text-sm font-medium text-gray-900">
              {categoryLabel ?? 'Unknown'}
            </span>
            <SeverityBadge severity={incident.severity} language={language} />
            <StatusBadge status={incident.status} language={language} />
          </div>

          <p className="text-sm text-gray-600 line-clamp-2 mb-2">
            {incident.description}
          </p>

          <div className="flex items-center gap-3 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {incident.location_text ?? (language === 'te' ? 'స్థానం లేదు' : 'No location')}
            </span>
            <span>{formatRelativeTime(incident.created_at, language)}</span>
          </div>
        </div>
      </div>
    </button>
  );
}
