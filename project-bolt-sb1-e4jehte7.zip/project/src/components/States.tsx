import { Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function LoadingSpinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-8 h-8' };
  return (
    <Loader2
      className={`${sizes[size]} animate-spin text-blue-600`}
      role="status"
      aria-label="Loading"
    />
  );
}

export function FullPageLoader() {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <LoadingSpinner size="lg" />
      <p className="text-sm text-gray-500">{t('common.loading')}</p>
    </div>
  );
}

export function ErrorState({
  message,
  onRetry,
  retryLabel,
}: {
  message: string;
  onRetry?: () => void;
  retryLabel?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 gap-3 text-center">
      <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center">
        <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      </div>
      <p className="text-sm text-gray-600 max-w-md">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors"
        >
          {retryLabel ?? 'Retry'}
        </button>
      )}
    </div>
  );
}

export function EmptyState({
  message,
  icon: Icon,
}: {
  message: string;
  icon?: React.ComponentType<{ className?: string }>;
}) {
  const DefaultIcon = Icon ?? (() => <div className="w-6 h-6" />);
  return (
    <div className="flex flex-col items-center justify-center py-12 gap-3 text-center">
      <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-400">
        <DefaultIcon className="w-6 h-6" />
      </div>
      <p className="text-sm text-gray-500 max-w-md">{message}</p>
    </div>
  );
}
