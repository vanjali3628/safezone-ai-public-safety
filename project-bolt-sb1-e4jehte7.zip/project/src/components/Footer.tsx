import { Shield, Phone, AlertTriangle, Heart } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';

export function Footer() {
  const { t } = useLanguage();
  const { navigate } = useRouter();

  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-blue-400" />
              <span className="font-bold text-white">{t('appName')}</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">{t('tagline')}</p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white mb-3">{t('footer.disclaimer')}</h3>
            <p className="text-xs text-gray-400 leading-relaxed">{t('disclaimer')}</p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white mb-3">{t('nav.emergency')}</h3>
            <a
              href="tel:112"
              className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors mb-2"
            >
              <Phone className="w-4 h-4 text-red-400" />
              <span>{t('footer.emergencyCall')}</span>
            </a>
            <button
              onClick={() => navigate('emergency')}
              className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
            >
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>{t('emergency.title')}</span>
            </button>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500">{t('footer.copyright')}</p>
          <p className="text-xs text-gray-500 flex items-center gap-1">
            <Heart className="w-3 h-3 text-red-400" />
            <span>{t('footer.sampleNote')}</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
