import { AlertTriangle, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function DisclaimerBanner() {
  const { t, language } = useLanguage();

  return (
    <div className="bg-amber-50 border-b border-amber-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" aria-hidden="true" />
          <p className="text-xs text-amber-800 leading-relaxed">
            {language === 'te'
              ? 'కమ్యూనిటీ నివేదికలు స్వయంచాలకంగా ధృవీకరించబడవు. అత్యవసరం కోసం 112 కు కాల్ చేయండి.'
              : t('disclaimer')}
          </p>
        </div>
      </div>
    </div>
  );
}

export function EmergencyCallBar() {
  const { t } = useLanguage();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-30 bg-red-600 text-white md:hidden">
      <a
        href="tel:112"
        className="flex items-center justify-center gap-2 py-3 font-semibold text-sm"
        aria-label="Call emergency number 112"
      >
        <AlertTriangle className="w-4 h-4" />
        {t('footer.emergencyCall')}
      </a>
    </div>
  );
}
