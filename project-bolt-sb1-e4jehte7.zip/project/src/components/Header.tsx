import { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter, type Page } from '@/contexts/RouterContext';
import type { TranslationKey } from '@/lib/i18n';

export function Header() {
  const { t, language, toggleLanguage } = useLanguage();
  const { currentPage, navigate } = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navItems: { page: Page; key: TranslationKey }[] = [
    { page: 'home', key: 'nav.home' },
    { page: 'report', key: 'nav.report' },
    { page: 'map', key: 'nav.map' },
    { page: 'emergency', key: 'nav.emergency' },
    { page: 'assistant', key: 'nav.assistant' },
    { page: 'track', key: 'nav.trackReport' },
  ];

  const handleNavigate = (page: Page) => {
    navigate(page);
    setMobileOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-200 ${
        scrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm' : 'bg-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={() => handleNavigate('home')}
            className="flex items-center"
            aria-label="SafeZone AI home"
          >
            <Logo />
          </button>

          <nav className="hidden lg:flex items-center gap-1" aria-label="Main navigation">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavigate(item.page)}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentPage === item.page
                    ? 'text-blue-700 bg-blue-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
                aria-current={currentPage === item.page ? 'page' : undefined}
              >
                {t(item.key)}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md transition-colors"
              aria-label={`Switch to ${language === 'en' ? 'Telugu' : 'English'}`}
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'en' ? 'తెలుగు' : 'English'}</span>
            </button>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors"
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileOpen}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <nav
            className="lg:hidden py-3 border-t border-gray-100"
            aria-label="Mobile navigation"
          >
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavigate(item.page)}
                className={`block w-full text-left px-3 py-2.5 text-sm font-medium rounded-md transition-colors ${
                  currentPage === item.page
                    ? 'text-blue-700 bg-blue-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
                aria-current={currentPage === item.page ? 'page' : undefined}
              >
                {t(item.key)}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
