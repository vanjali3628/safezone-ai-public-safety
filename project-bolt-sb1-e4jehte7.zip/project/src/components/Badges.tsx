import type { Severity, IncidentStatus, Language } from '@/types';
import { SEVERITY_COLORS, SEVERITY_LABELS, SEVERITY_ICONS } from '@/lib/constants';
import { STATUS_COLORS, STATUS_LABELS } from '@/lib/constants';
import { AlertCircle, AlertTriangle, Siren, Info, CheckCircle2, Clock, XCircle, Loader2 } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export function SeverityBadge({ severity, language }: { severity: Severity; language: Language }) {
  const colors = SEVERITY_COLORS[severity];
  const label = language === 'te' ? SEVERITY_LABELS[severity].te : SEVERITY_LABELS[severity].en;
  const iconName = SEVERITY_ICONS[severity];
  const Icon = iconMap[iconName] ?? AlertCircle;

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${colors.bg} ${colors.text} border ${colors.border}`}
    >
      <Icon className="w-3 h-3" aria-hidden="true" />
      {label}
    </span>
  );
}

export function StatusBadge({ status, language }: { status: IncidentStatus; language: Language }) {
  const colors = STATUS_COLORS[status];
  const label = language === 'te' ? STATUS_LABELS[status].te : STATUS_LABELS[status].en;
  const Icon = statusIconMap[status] ?? Clock;

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${colors.bg} ${colors.text} border ${colors.border}`}
    >
      <Icon className="w-3 h-3" aria-hidden="true" />
      {label}
    </span>
  );
}

const iconMap: Record<string, LucideIcon> = {
  Info,
  AlertCircle,
  AlertTriangle,
  Siren,
};

const statusIconMap: Record<IncidentStatus, LucideIcon> = {
  reported: Clock,
  verified: CheckCircle2,
  in_progress: Loader2,
  resolved: CheckCircle2,
  rejected: XCircle,
};
