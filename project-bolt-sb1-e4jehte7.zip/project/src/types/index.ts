export type Severity = 'low' | 'medium' | 'high' | 'critical';

export type IncidentStatus =
  | 'reported'
  | 'verified'
  | 'in_progress'
  | 'resolved'
  | 'rejected';

export type Language = 'en' | 'te';

export type IncidentCategory = {
  id: number;
  code: string;
  label_en: string;
  label_te: string;
  default_severity: Severity;
  icon: string;
  sort_order: number;
};

export type Incident = {
  id: string;
  tracking_code: string;
  category_id: number;
  description: string;
  latitude: number | null;
  longitude: number | null;
  location_text: string | null;
  severity: Severity;
  status: IncidentStatus;
  image_url: string | null;
  is_public: boolean;
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
  // Joined fields
  category?: IncidentCategory;
};

export type IncidentEvent = {
  id: string;
  incident_id: string;
  event_type: 'created' | 'status_changed' | 'verified' | 'resolved' | 'rejected';
  old_status: IncidentStatus | null;
  new_status: IncidentStatus | null;
  note: string | null;
  created_by: string | null;
  created_at: string;
};

export type EmergencyContact = {
  id: number;
  name_en: string;
  name_te: string;
  phone: string;
  description_en: string | null;
  description_te: string | null;
  category: string;
  sort_order: number;
};

export type IncidentReportInput = {
  category_id: number;
  description: string;
  latitude: number | null;
  longitude: number | null;
  location_text: string | null;
  severity: Severity;
  reporter_contact: string | null;
  image_url: string | null;
  is_public: boolean;
};

export type ValidationError = {
  field: string;
  message: string;
  message_te: string;
};

export type IncidentFilters = {
  category: string | null;
  status: IncidentStatus | null;
  severity: Severity | null;
  search: string | null;
  page: number;
  pageSize: number;
};

export type SafetyTip = {
  id: string;
  categoryCode: string;
  title_en: string;
  title_te: string;
  steps_en: string[];
  steps_te: string[];
  warning_en: string;
  warning_te: string;
};
