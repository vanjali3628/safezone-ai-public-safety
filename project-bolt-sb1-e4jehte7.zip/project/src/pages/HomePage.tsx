import { AlertTriangle, MapPin, Phone, ArrowRight, ShieldCheck, Eye, Clock, Heart, FileText } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';
import { DISCLAIMER_EN, DISCLAIMER_TE } from '@/lib/constants';

export function HomePage() {
  const { t, language } = useLanguage();
  const { navigate } = useRouter();

  const features = [
    {
      icon: AlertTriangle,
      titleEn: 'Report Hazards',
      titleTe: 'ప్రమాదాలు నివేదించండి',
      descEn: 'Report road hazards, waterlogging, fire risks, and more. No account needed.',
      descTe: 'రహదారి ప్రమాదాలు, నీటి నిల్వ, అగ్ని ముప్పు మరియు మరిన్ని నివేదించండి. ఖాతా అవసరం లేదు.',
      action: () => navigate('report'),
      cta: t('hero.cta.report'),
    },
    {
      icon: MapPin,
      titleEn: 'Safety Map',
      titleTe: 'భద్రతా పటం',
      descEn: 'View reported hazards in your area on an interactive map or accessible list.',
      descTe: 'మీ ప్రాంతంలో నివేదించబడిన ప్రమాదాలను పటం లేదా జాబితాలో చూడండి.',
      action: () => navigate('map'),
      cta: t('hero.cta.viewMap'),
    },
    {
      icon: Phone,
      titleEn: 'Emergency Contacts',
      titleTe: 'అత్యవసర సంఖ్యలు',
      descEn: 'Verified emergency numbers for India, plus practical safety instructions.',
      descTe: 'భారతదేశం కోసం ధృవీకరించబడిన అత్యవసర నంబర్‌లు మరియు భద్రతా సూచనలు.',
      action: () => navigate('emergency'),
      cta: t('hero.cta.emergency'),
    },
  ];

  const steps = [
    {
      icon: Eye,
      titleEn: 'Discover a Hazard',
      titleTe: 'ప్రమాదాన్ని కనుగొనండి',
      descEn: 'Spot a safety hazard in your community.',
      descTe: 'మీ కమ్యూనిటీలో భద్రతా ప్రమాదాన్ని గుర్తించండి.',
    },
    {
      icon: AlertTriangle,
      titleEn: 'Report It',
      titleTe: 'నివేదించండి',
      descEn: 'Submit a report with category, description, and location.',
      descTe: 'వర్గం, వివరణ మరియు స్థానంతో నివేదిక సమర్పించండి.',
    },
    {
      icon: Clock,
      titleEn: 'Track Status',
      titleTe: 'స్థితిని ట్రాక్ చేయండి',
      descEn: 'Use your tracking code to follow the report status.',
      descTe: 'మీ ట్రాకింగ్ కోడ్‌తో నివేదిక స్థితిని చూడండి.',
    },
    {
      icon: ShieldCheck,
      titleEn: 'Stay Safe',
      titleTe: 'సురక్షితంగా ఉండండి',
      descEn: 'Access safety guidance and emergency contacts.',
      descTe: 'భద్రతా మార్గదర్శకత్వం మరియు అత్యవసర సంఖ్యలను పొందండి.',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-cyan-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10" aria-hidden="true">
          <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-400 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full text-sm mb-6 backdrop-blur-sm">
              <ShieldCheck className="w-4 h-4" />
              <span>{t('tagline')}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold leading-tight mb-6">
              {t('hero.title')}
            </h1>
            <p className="text-lg text-blue-100 leading-relaxed mb-8 max-w-2xl">
              {t('hero.subtitle')}
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => navigate('report')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white text-blue-800 font-semibold rounded-lg hover:bg-blue-50 transition-colors shadow-lg"
              >
                <AlertTriangle className="w-5 h-5" />
                {t('hero.cta.report')}
              </button>
              <button
                onClick={() => navigate('map')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white/10 text-white font-semibold rounded-lg hover:bg-white/20 transition-colors backdrop-blur-sm border border-white/20"
              >
                <MapPin className="w-5 h-5" />
                {t('hero.cta.viewMap')}
              </button>
              <button
                onClick={() => navigate('emergency')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition-colors shadow-lg"
              >
                <Phone className="w-5 h-5" />
                {t('hero.cta.emergency')}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-blue-200 transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {language === 'te' ? feature.titleTe : feature.titleEn}
              </h3>
              <p className="text-sm text-gray-600 leading-relaxed mb-4">
                {language === 'te' ? feature.descTe : feature.descEn}
              </p>
              <button
                onClick={feature.action}
                className="inline-flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors"
              >
                {feature.cta}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-gray-50 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">
            {language === 'te' ? 'ఎలా పనిచేస్తుంది' : 'How It Works'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <div key={i} className="relative text-center">
                <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white border border-gray-200 shadow-sm mb-4">
                  <step.icon className="w-7 h-7 text-blue-600" />
                  <span className="absolute -top-2 -right-2 w-6 h-6 bg-blue-600 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {i + 1}
                  </span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  {language === 'te' ? step.titleTe : step.titleEn}
                </h3>
                <p className="text-sm text-gray-500">
                  {language === 'te' ? step.descTe : step.descEn}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <h3 className="font-semibold text-amber-900 mb-1 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              {language === 'te' ? 'ముఖ్య సూచన' : 'Important Notice'}
            </h3>
            <p className="text-sm text-amber-800 leading-relaxed">
              {language === 'te' ? DISCLAIMER_TE : DISCLAIMER_EN}
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-8 md:p-12 text-center text-white">
          <Heart className="w-10 h-10 mx-auto mb-4 text-white/90" />
          <h2 className="text-2xl font-bold mb-3">
            {language === 'te' ? 'మీ కమ్యూనిటీ భద్రతకు దోహదపడండి' : 'Help Keep Your Community Safe'}
          </h2>
          <p className="text-blue-100 mb-6 max-w-xl mx-auto">
            {language === 'te'
              ? 'ఒక ప్రమాదాన్ని నివేదించడం ద్వారా, మీరు ఇతరులను సురక్షితంగా ఉంచడంలో సహాయపడతారు.'
              : 'By reporting a hazard, you help keep others safe and informed.'}
          </p>
          <button
            onClick={() => navigate('report')}
            className="inline-flex items-center gap-2 px-6 py-3 bg-white text-blue-700 font-semibold rounded-lg hover:bg-blue-50 transition-colors shadow-lg"
          >
            <AlertTriangle className="w-5 h-5" />
            {t('common.reportNow')}
          </button>
        </div>
      </section>
    </div>
  );
}
