import { useState } from 'react';
import { Phone, ChevronDown, ChevronUp, AlertTriangle, Lightbulb, ExternalLink } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchEmergencyContacts } from '@/lib/api';
import { useAsyncData } from '@/hooks/useAsyncData';
import { LoadingSpinner, ErrorState } from '@/components/States';
import { SAFETY_TIPS } from '@/lib/constants';
import type { EmergencyContact } from '@/types';

export function EmergencyPage() {
  const { t, language } = useLanguage();
  const { data: contacts, loading, error, reload } = useAsyncData(
    () => fetchEmergencyContacts(),
    [],
  );
  const [expandedTip, setExpandedTip] = useState<string | null>(null);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">{t('emergency.title')}</h1>
        <p className="text-sm text-gray-500">{t('emergency.subtitle')}</p>
      </div>

      {/* Big emergency call button */}
      <div className="bg-red-600 text-white rounded-2xl p-6 mb-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
            <Phone className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm text-red-100">{t('footer.emergencyCall')}</p>
            <p className="text-3xl font-bold">112</p>
          </div>
        </div>
        <a
          href="tel:112"
          className="px-6 py-3 bg-white text-red-600 font-bold rounded-xl hover:bg-red-50 transition-colors flex items-center gap-2"
          aria-label="Call 112"
        >
          <Phone className="w-5 h-5" />
          {t('emergency.callNow')}
        </a>
      </div>

      {/* Contacts grid */}
      <section aria-label="Emergency contacts">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          {language === 'te' ? 'అత్యవసర సంఖ్యలు' : 'Emergency Numbers'}
        </h2>
        {loading ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner size="lg" />
          </div>
        ) : error ? (
          <ErrorState message={t('common.error')} onRetry={reload} retryLabel={t('common.retry')} />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {contacts?.map((contact: EmergencyContact) => (
              <div
                key={contact.id}
                className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm">
                      {language === 'te' ? contact.name_te : contact.name_en}
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {language === 'te' ? contact.description_te : contact.description_en}
                    </p>
                  </div>
                </div>
                <a
                  href={`tel:${contact.phone}`}
                  className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                  aria-label={`${t('emergency.callNow')} ${contact.phone}`}
                >
                  <Phone className="w-4 h-4" />
                  {contact.phone}
                </a>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Safety tips */}
      <section aria-label="Safety tips" className="mt-12">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-amber-500" />
          {t('emergency.safetyTips')}
        </h2>
        <div className="space-y-3">
          {SAFETY_TIPS.map((tip) => (
            <div
              key={tip.id}
              className="bg-white border border-gray-200 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedTip(expandedTip === tip.id ? null : tip.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                aria-expanded={expandedTip === tip.id}
              >
                <span className="font-medium text-gray-900 text-sm">
                  {language === 'te' ? tip.title_te : tip.title_en}
                </span>
                {expandedTip === tip.id ? (
                  <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                )}
              </button>
              {expandedTip === tip.id && (
                <div className="px-4 pb-4 border-t border-gray-100 pt-4">
                  <ol className="space-y-2 mb-4">
                    {(language === 'te' ? tip.steps_te : tip.steps_en).map((step, i) => (
                      <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                        <span className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center mt-0.5">
                          {i + 1}
                        </span>
                        <span className="leading-relaxed">{step}</span>
                      </li>
                    ))}
                  </ol>
                  <div className="flex items-start gap-2 bg-amber-50 rounded-lg p-3">
                    <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-800 leading-relaxed">
                      {language === 'te' ? tip.warning_te : tip.warning_en}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800 leading-relaxed">
          {language === 'te'
            ? 'ఈ సమాచారం భారత ప్రభుత్వ అధికారిక వనరుల ఆధారంగా అందించబడింది. అత్యవసర పరిస్థితులలో ఎల్లప్పుడూ అధికారిక నంబర్‌లకు కాల్ చేయండి.'
            : 'This information is provided based on official Government of India resources. Always call official numbers in emergency situations.'}
        </p>
      </div>
    </div>
  );
}
