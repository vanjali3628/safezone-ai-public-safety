import { useState } from 'react';
import { Search, ArrowLeft, MapPin, Clock, AlertTriangle, Copy, CheckCircle2, XCircle, Loader2, History } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';
import { useToast } from '@/contexts/ToastContext';
import { fetchIncidentByTrackingCode } from '@/lib/api';
import { isValidTrackingCode, normalizeTrackingCode } from '@/lib/trackingCode';
import { SeverityBadge, StatusBadge } from '@/components/Badges';
import { LoadingSpinner, ErrorState } from '@/components/States';
import { formatDateTime, formatRelativeTime } from '@/lib/format';
import { STATUS_LABELS } from '@/lib/constants';
import type { Incident, IncidentEvent, Language } from '@/types';

export function TrackPage() {
  const { t, language } = useLanguage();
  const { navigate } = useRouter();
  const { showToast } = useToast();
  const [code, setCode] = useState('');
  const [codeError, setCodeError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ incident: Incident; events: IncidentEvent[] } | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = normalizeTrackingCode(code);
    if (!isValidTrackingCode(normalized)) {
      setCodeError(language === 'te' ? 'చెల్లని కోడ్ ఫార్మాట్ (ఉదా., SZ-A8F3K2AB)' : 'Invalid code format (e.g., SZ-A8F3K2AB)');
      return;
    }
    setCodeError(null);
    setLoading(true);
    setResult(null);
    setNotFound(false);
    setError(false);

    try {
      const data = await fetchIncidentByTrackingCode(normalized);
      if (data.incident) {
        setResult({ incident: data.incident, events: data.events });
      } else {
        setNotFound(true);
      }
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setCode('');
    setResult(null);
    setNotFound(false);
    setError(false);
    setCodeError(null);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate('home')}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        {t('common.back')}
      </button>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">{t('myReports.title')}</h1>
        <p className="text-sm text-gray-500">{t('myReports.subtitle')}</p>
      </div>

      {/* Search form */}
      <form onSubmit={handleSearch} className="mb-6">
        <label htmlFor="tracking-code" className="block text-sm font-medium text-gray-900 mb-1.5">
          {t('myReports.enterCode')}
        </label>
        <div className="flex gap-2">
          <input
            id="tracking-code"
            type="text"
            value={code}
            onChange={(e) => {
              setCode(e.target.value.toUpperCase());
              setCodeError(null);
            }}
            placeholder={t('myReports.code.placeholder')}
            className="flex-1 px-3 py-2.5 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            aria-invalid={!!codeError}
            aria-describedby={codeError ? 'code-error' : undefined}
          />
          <button
            type="submit"
            disabled={loading || !code.trim()}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? <LoadingSpinner size="sm" /> : <Search className="w-4 h-4" />}
            {t('myReports.find')}
          </button>
        </div>
        {codeError && (
          <p id="code-error" className="text-xs text-red-600 mt-1" role="alert">
            {codeError}
          </p>
        )}
      </form>

      {/* Results */}
      {loading && <div className="flex justify-center py-12"><LoadingSpinner size="lg" /></div>}

      {error && (
        <ErrorState
          message={t('myReports.error')}
          onRetry={() => handleSearch({ preventDefault: () => {} } as React.FormEvent)}
          retryLabel={t('myReports.retry')}
        />
      )}

      {notFound && (
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-8 text-center">
          <XCircle className="w-10 h-10 text-gray-400 mx-auto mb-3" />
          <p className="text-sm text-gray-600 mb-4">{t('myReports.notFound')}</p>
          <button
            onClick={handleReset}
            className="text-sm font-medium text-blue-600 hover:text-blue-700"
          >
            {t('myReports.trackAnother')}
          </button>
        </div>
      )}

      {result && (
        <ReportDetails
          incident={result.incident}
          events={result.events}
          language={language}
          t={t}
          onReset={handleReset}
          onCopy={() => {
            navigator.clipboard?.writeText(result.incident.tracking_code);
            showToast(language === 'te' ? 'కాపీ చేయబడింది' : 'Copied', 'success');
          }}
        />
      )}
    </div>
  );
}

function ReportDetails({
  incident,
  events,
  language,
  t,
  onReset,
  onCopy,
}: {
  incident: Incident;
  events: IncidentEvent[];
  language: Language;
  t: (key: import('@/lib/i18n').TranslationKey) => string;
  onReset: () => void;
  onCopy: () => void;
}) {
  const categoryLabel =
    language === 'te' ? incident.category?.label_te : incident.category?.label_en;

  return (
    <div className="space-y-4">
      {/* Report card */}
      <div className="bg-white border border-gray-200 rounded-2xl p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <SeverityBadge severity={incident.severity} language={language} />
              <StatusBadge status={incident.status} language={language} />
            </div>
            <p className="text-sm font-medium text-gray-900">{categoryLabel}</p>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1.5 bg-blue-50 px-2 py-1 rounded-md">
              <code className="text-sm font-mono font-bold text-blue-900">{incident.tracking_code}</code>
              <button onClick={onCopy} className="text-blue-600 hover:text-blue-800" aria-label="Copy tracking code">
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-3 pt-4 border-t border-gray-100">
          <div>
            <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.description')}</p>
            <p className="text-sm text-gray-700 leading-relaxed">{incident.description}</p>
          </div>

          {incident.location_text && (
            <div>
              <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.location')}</p>
              <p className="text-sm text-gray-700 flex items-center gap-1">
                <MapPin className="w-4 h-4 text-gray-400" />
                {incident.location_text}
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div>
              <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.reportedOn')}</p>
              <p className="text-sm text-gray-700">{formatDateTime(incident.created_at, language)}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.lastUpdated')}</p>
              <p className="text-sm text-gray-700">{formatRelativeTime(incident.updated_at, language)}</p>
            </div>
          </div>

          {incident.resolved_at && (
            <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 rounded-lg p-3">
              <CheckCircle2 className="w-4 h-4" />
              <p className="text-sm">
                {language === 'te' ? 'పరిష్కరించబడింది' : 'Resolved'}: {formatDateTime(incident.resolved_at, language)}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Status history */}
      <div className="bg-white border border-gray-200 rounded-2xl p-6">
        <h2 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <History className="w-4 h-4 text-gray-400" />
          {t('myReports.statusHistory')}
        </h2>
        <ol className="space-y-3">
          {events.map((event, i) => {
            const statusLabel =
              event.new_status && (language === 'te'
                ? STATUS_LABELS[event.new_status]?.te
                : STATUS_LABELS[event.new_status]?.en);
            return (
              <li key={event.id} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-2.5 h-2.5 rounded-full ${i === events.length - 1 ? 'bg-blue-600' : 'bg-gray-300'}`} />
                  {i < events.length - 1 && <div className="w-0.5 h-6 bg-gray-200" />}
                </div>
                <div className="flex-1 pb-1">
                  <p className="text-sm text-gray-700">
                    {event.event_type === 'created'
                      ? language === 'te'
                        ? 'నివేదిక సమర్పించబడింది'
                        : 'Report submitted'
                      : `${language === 'te' ? 'స్థితి మార్చబడింది' : 'Status changed'}: ${statusLabel}`}
                  </p>
                  <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3" />
                    {formatRelativeTime(event.created_at, language)}
                  </p>
                </div>
              </li>
            );
          })}
        </ol>
      </div>

      <div className="text-center">
        <button
          onClick={onReset}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-600 hover:text-blue-700"
        >
          <Search className="w-4 h-4" />
          {t('myReports.trackAnother')}
        </button>
      </div>
    </div>
  );
}
