import { useState, useCallback, useRef } from 'react';
import { AlertTriangle, MapPin, Camera, CheckCircle2, ArrowLeft, Loader2, Copy, AlertCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';
import { useToast } from '@/contexts/ToastContext';
import { fetchCategories, submitIncidentReport, checkDuplicateReport } from '@/lib/api';
import { validateIncidentReport, sanitizeText, sanitizeLocationText, sanitizeContact } from '@/lib/validation';
import type { IncidentCategory, Severity, ValidationError, IncidentReportInput } from '@/types';
import { SEVERITY_LEVELS, SEVERITY_LABELS, MAX_DESCRIPTION_LENGTH } from '@/lib/constants';
import { useAsyncData } from '@/hooks/useAsyncData';

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png'];
const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB

export function ReportPage() {
  const { t, language } = useLanguage();
  const { navigate } = useRouter();
  const { showToast } = useToast();
  const { data: categories, loading: catLoading, error: catError, reload: catReload } =
    useAsyncData(() => fetchCategories(), []);

  const [form, setForm] = useState<Partial<IncidentReportInput>>({
    category_id: undefined,
    description: '',
    latitude: null,
    longitude: null,
    location_text: '',
    severity: 'medium',
    reporter_contact: '',
    image_url: null,
    is_public: true,
  });
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ trackingCode: string } | null>(null);
  const [duplicateWarning, setDuplicateWarning] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateField = useCallback((field: keyof IncidentReportInput, value: unknown) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => prev.filter((e) => e.field !== field));
  }, []);

  const handleLocation = useCallback(() => {
    if (!navigator.geolocation) {
      showToast(language === 'te' ? 'జియోలొకేషన్ అందుబాటులో లేదు' : 'Geolocation not available', 'error');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        updateField('latitude', Number(pos.coords.latitude.toFixed(7)));
        updateField('longitude', Number(pos.coords.longitude.toFixed(7)));
        setLocating(false);
        showToast(language === 'te' ? 'స్థానం కనుగొనబడింది' : 'Location captured', 'success');
      },
      (err) => {
        setLocating(false);
        showToast(
          language === 'te'
            ? 'స్థానం పొందడం విఫలమైంది'
            : `Failed to get location: ${err.message}`,
          'error',
        );
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
    );
  }, [updateField, showToast, language]);

  const handleImageUpload = useCallback(
    async (file: File) => {
      setImageError(null);

      if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
        setImageError(language === 'te' ? 'JPG లేదా PNG మాత్రమే' : 'Only JPG or PNG allowed');
        return;
      }
      if (file.size > MAX_IMAGE_SIZE) {
        setImageError(language === 'te' ? 'ఫోటో 5MB కంటే తక్కువ ఉండాలి' : 'Photo must be under 5MB');
        return;
      }

      // For this demo, we convert to a data URL (in production, use Supabase Storage)
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        updateField('image_url', result);
      };
      reader.onerror = () => {
        setImageError(language === 'te' ? 'ఫోటో అప్‌లోడ్ విఫలమైంది' : 'Failed to upload photo');
      };
      reader.readAsDataURL(file);
    },
    [updateField, language],
  );

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) handleImageUpload(file);
    },
    [handleImageUpload],
  );

  const validateForm = (): boolean => {
    const validationErrors = validateIncidentReport(form);
    setErrors(validationErrors);
    return validationErrors.length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!categories || categories.length === 0) return;

    if (!validateForm()) {
      showToast(language === 'te' ? 'దయచేసి పొరపాట్లను సరిచేయండి' : 'Please fix the errors', 'error');
      return;
    }

    setSubmitting(true);
    try {
      // Check for duplicates
      const isDup = await checkDuplicateReport(
        form.description ?? '',
        form.latitude ?? null,
        form.longitude ?? null,
      );
      setDuplicateWarning(isDup);

      const result = await submitIncidentReport(
        form as IncidentReportInput,
        categories,
      );
      setSuccess({ trackingCode: result.trackingCode });
      showToast(t('report.success'), 'success');
    } catch (err) {
      showToast(t('report.error'), 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const getFieldError = (field: string): ValidationError | undefined =>
    errors.find((e) => e.field === field);

  if (catLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (catError) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 text-center">
        <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-4" />
        <p className="text-gray-600 mb-4">{t('common.error')}</p>
        <button
          onClick={catReload}
          className="px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 rounded-md hover:bg-blue-100"
        >
          {t('common.retry')}
        </button>
      </div>
    );
  }

  if (success) {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white border border-gray-200 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">{t('report.success')}</h2>
          <p className="text-sm text-gray-500 mb-6">{t('report.success.note')}</p>

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
            <p className="text-xs text-blue-600 mb-1">{t('report.success.trackingCode')}</p>
            <div className="flex items-center justify-center gap-3">
              <code className="text-2xl font-mono font-bold text-blue-900 tracking-wider">
                {success.trackingCode}
              </code>
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(success.trackingCode);
                  showToast(language === 'te' ? 'కాపీ చేయబడింది' : 'Copied', 'success');
                }}
                className="p-2 text-blue-600 hover:bg-blue-100 rounded-md transition-colors"
                aria-label="Copy tracking code"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => {
                setSuccess(null);
                setForm({
                  category_id: undefined,
                  description: '',
                  latitude: null,
                  longitude: null,
                  location_text: '',
                  severity: 'medium',
                  reporter_contact: '',
                  image_url: null,
                  is_public: true,
                });
                setErrors([]);
                setDuplicateWarning(false);
              }}
              className="px-5 py-2.5 text-sm font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
            >
              {t('report.new')}
            </button>
            <button
              onClick={() => {
                navigate('track');
              }}
              className="px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
            >
              {t('nav.trackReport')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate('home')}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        {t('common.back')}
      </button>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">{t('report.title')}</h1>
        <p className="text-sm text-gray-500">{t('report.subtitle')}</p>
      </div>

      {duplicateWarning && (
        <div className="mb-4 bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800">{t('report.duplicate.warning')}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6" noValidate>
        {/* Category */}
        <FormField
          label={t('report.category')}
          required
          error={getFieldError('category_id')}
          language={language}
        >
          <select
            value={form.category_id ?? ''}
            onChange={(e) => updateField('category_id', Number(e.target.value))}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            aria-required="true"
            aria-invalid={!!getFieldError('category_id')}
          >
            <option value="">{t('report.category.placeholder')}</option>
            {categories?.map((cat: IncidentCategory) => (
              <option key={cat.id} value={cat.id}>
                {language === 'te' ? cat.label_te : cat.label_en}
              </option>
            ))}
          </select>
        </FormField>

        {/* Description */}
        <FormField
          label={t('report.description')}
          required
          error={getFieldError('description')}
          language={language}
          help={t('report.description.help')}
        >
          <textarea
            value={form.description ?? ''}
            onChange={(e) => updateField('description', e.target.value)}
            placeholder={t('report.description.placeholder')}
            rows={4}
            maxLength={MAX_DESCRIPTION_LENGTH}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-y"
            aria-required="true"
            aria-invalid={!!getFieldError('description')}
          />
          <p className="text-xs text-gray-400 mt-1">
            {(form.description ?? '').length}/{MAX_DESCRIPTION_LENGTH}
          </p>
        </FormField>

        {/* Severity */}
        <FormField
          label={t('report.severity')}
          required
          error={getFieldError('severity')}
          language={language}
        >
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {SEVERITY_LEVELS.map((sev) => (
              <button
                key={sev}
                type="button"
                onClick={() => updateField('severity', sev)}
                className={`px-3 py-2 text-sm font-medium rounded-lg border transition-colors ${
                  form.severity === sev
                    ? 'bg-blue-50 border-blue-400 text-blue-700'
                    : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
                }`}
                aria-pressed={form.severity === sev}
              >
                {language === 'te' ? SEVERITY_LABELS[sev].te : SEVERITY_LABELS[sev].en}
              </button>
            ))}
          </div>
        </FormField>

        {/* Location */}
        <FormField
          label={`${t('report.location')} (${t('common.optional')})`}
          error={getFieldError('location_text')}
          language={language}
          help={t('report.location.help')}
        >
          <input
            type="text"
            value={form.location_text ?? ''}
            onChange={(e) => updateField('location_text', e.target.value)}
            placeholder={t('report.location.placeholder')}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mb-2"
          />
          <button
            type="button"
            onClick={handleLocation}
            disabled={locating}
            className="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors disabled:opacity-50"
          >
            {locating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <MapPin className="w-4 h-4" />
            )}
            {t('report.useMyLocation')}
          </button>
          {form.latitude != null && form.longitude != null && (
            <p className="text-xs text-gray-500 mt-2">
              📍 {form.latitude.toFixed(5)}, {form.longitude.toFixed(5)}
            </p>
          )}
          {getFieldError('coordinates') && (
            <p className="text-xs text-red-600 mt-1">
              {language === 'te' ? getFieldError('coordinates')?.message_te : getFieldError('coordinates')?.message}
            </p>
          )}
        </FormField>

        {/* Image */}
        <FormField
          label={`${t('report.image')} (${t('common.optional')})`}
          help={t('report.image.help')}
          language={language}
          error={imageError ? { field: 'image', message: imageError, message_te: imageError } : undefined}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png"
            onChange={handleFileChange}
            className="hidden"
            aria-label={t('report.image.button')}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <Camera className="w-4 h-4" />
            {t('report.image.button')}
          </button>
          {form.image_url && (
            <div className="mt-3 relative">
              <img
                src={form.image_url}
                alt="Uploaded preview"
                className="w-full max-w-xs rounded-lg border border-gray-200"
              />
              <button
                type="button"
                onClick={() => updateField('image_url', null)}
                className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                aria-label="Remove photo"
              >
                <AlertCircle className="w-4 h-4" />
              </button>
            </div>
          )}
        </FormField>

        {/* Contact */}
        <FormField
          label={`${t('report.contact')} (${t('common.optional')})`}
          error={getFieldError('reporter_contact')}
          language={language}
          help={t('report.contact.help')}
        >
          <input
            type="text"
            value={form.reporter_contact ?? ''}
            onChange={(e) => updateField('reporter_contact', e.target.value)}
            placeholder={t('report.contact.placeholder')}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </FormField>

        {/* Public toggle */}
        <div className="flex items-start gap-3">
          <input
            type="checkbox"
            id="is_public"
            checked={form.is_public ?? true}
            onChange={(e) => updateField('is_public', e.target.checked)}
            className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
          />
          <div>
            <label htmlFor="is_public" className="text-sm font-medium text-gray-900">
              {t('report.public')}
            </label>
            <p className="text-xs text-gray-500 mt-0.5">{t('report.public.help')}</p>
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              {t('report.submitting')}
            </>
          ) : (
            <>
              <AlertTriangle className="w-5 h-5" />
              {t('report.submit')}
            </>
          )}
        </button>
      </form>
    </div>
  );
}

function FormField({
  label,
  required,
  error,
  help,
  language,
  children,
}: {
  label: string;
  required?: boolean;
  error?: ValidationError;
  help?: string;
  language: 'en' | 'te';
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-900 mb-1.5">
        {label}
        {required && <span className="text-red-500 ml-0.5" aria-hidden="true">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-xs text-red-600 mt-1" role="alert">
          {language === 'te' ? error.message_te : error.message}
        </p>
      )}
      {help && !error && <p className="text-xs text-gray-400 mt-1">{help}</p>}
    </div>
  );
}
