import { useState, useRef, useEffect } from 'react';
import { Send, AlertTriangle, Phone, MessageSquare, ArrowLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';
import { generateSafetyResponse, type AssistantResponse } from '@/lib/safetyAssistant';

type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isEmergency?: boolean;
  contacts?: { name: string; phone: string }[];
};

export function AssistantPage() {
  const { t, language } = useLanguage();
  const { navigate } = useRouter();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: trimmed,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    // Simulate processing delay for UX
    await new Promise((resolve) => setTimeout(resolve, 300));

    const response: AssistantResponse = generateSafetyResponse(trimmed, language);
    const assistantMsg: ChatMessage = {
      id: `assistant-${Date.now()}`,
      role: 'assistant',
      content: response.text,
      isEmergency: response.isEmergency,
      contacts: response.suggestedContacts,
    };
    setMessages((prev) => [...prev, assistantMsg]);
    setLoading(false);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const suggestionsEn = ['Fire near my house', 'Road accident', 'Flood in my area', 'Electrical hazard'];
  const suggestionsTe = ['నా ఇంటి దగ్గర అగ్ని', 'రహదారి ప్రమాదం', 'నా ప్రాంతంలో వరద', 'విద్యుత్ ప్రమాదం'];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate('home')}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        {t('common.back')}
      </button>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1 flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-blue-600" />
          {t('assistant.title')}
        </h1>
        <p className="text-sm text-gray-500">{t('assistant.subtitle')}</p>
      </div>

      {/* Chat container */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden flex flex-col" style={{ minHeight: '500px' }}>
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[500px]">
          {messages.length === 0 && (
            <div className="text-center py-12">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-7 h-7 text-blue-600" />
              </div>
              <p className="text-sm text-gray-500 mb-6 max-w-md mx-auto">{t('assistant.empty')}</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {(language === 'te' ? suggestionsTe : suggestionsEn).map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setInput(suggestion)}
                    className="px-3 py-1.5 text-sm text-blue-700 bg-blue-50 border border-blue-200 rounded-full hover:bg-blue-100 transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white rounded-br-sm'
                    : msg.isEmergency
                      ? 'bg-red-50 border border-red-200 text-gray-800 rounded-bl-sm'
                      : 'bg-gray-100 text-gray-800 rounded-bl-sm'
                }`}
              >
                {msg.isEmergency && (
                  <div className="flex items-center gap-2 mb-2 text-red-600 font-semibold text-sm">
                    <AlertTriangle className="w-4 h-4" />
                    {t('assistant.emergency.warning')}
                  </div>
                )}
                <p className="text-sm leading-relaxed whitespace-pre-line">{msg.content}</p>
                {msg.contacts && msg.contacts.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {msg.contacts.map((contact) => (
                      <a
                        key={contact.phone}
                        href={`tel:${contact.phone}`}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Phone className="w-3 h-3" />
                        {contact.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-2xl rounded-bl-sm px-4 py-3">
                <div className="flex gap-1.5">
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-gray-100 p-4">
          <div className="flex items-end gap-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t('assistant.placeholder')}
              rows={1}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none max-h-32"
              aria-label={t('assistant.placeholder')}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className="p-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={t('assistant.send')}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="mt-4 flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3">
        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800 leading-relaxed">{t('assistant.disclaimer')}</p>
      </div>
    </div>
  );
}
