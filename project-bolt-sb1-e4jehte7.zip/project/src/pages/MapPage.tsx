import { useState, useEffect, useCallback, useMemo } from 'react';
import { MapPin, List, Filter, X, Search, Construction, Waves, Flame, ShieldAlert, Zap, Biohazard, Building2, Dog, AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchAllPublicIncidentsForMap, fetchPublicIncidents } from '@/lib/api';
import { useAsyncData } from '@/hooks/useAsyncData';
import { IncidentCard } from '@/components/IncidentCard';
import { LoadingSpinner, ErrorState, EmptyState } from '@/components/States';
import type { Incident, IncidentCategory, IncidentStatus, Severity, IncidentFilters } from '@/types';
import { SEVERITY_LEVELS, SEVERITY_LABELS, STATUS_ORDER, STATUS_LABELS, SEVERITY_COLORS, PAGE_SIZE } from '@/lib/constants';
import { formatRelativeTime } from '@/lib/format';
import type { LucideIcon } from 'lucide-react';

const categoryIcons: Record<string, LucideIcon> = {
  Construction, Waves, Flame, ShieldAlert, Zap, Biohazard, Building2, Dog, AlertTriangle,
};

export function MapPage() {
  const { t, language } = useLanguage();
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [filters, setFilters] = useState<IncidentFilters>({
    category: null,
    status: null,
    severity: null,
    search: null,
    page: 1,
    pageSize: PAGE_SIZE,
  });
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  // Fetch all incidents for map view
  const {
    data: mapIncidents,
    loading: mapLoading,
    error: mapError,
    reload: mapReload,
  } = useAsyncData(() => fetchAllPublicIncidentsForMap(), []);

  // Fetch paginated incidents for list view
  const {
    data: listData,
    loading: listLoading,
    error: listError,
    reload: listReload,
  } = useAsyncData(
    () => fetchPublicIncidents(filters),
    [filters.category, filters.status, filters.severity, filters.search, filters.page],
  );

  const categories = useAsyncData(
    async () => {
      const { supabase } = await import('@/lib/supabase');
      const { data } = await supabase.from('incident_categories').select('*').order('sort_order');
      return (data ?? []) as IncidentCategory[];
    },
    [],
  );

  const filteredMapIncidents = useMemo(() => {
    if (!mapIncidents) return [];
    return mapIncidents.filter((inc) => {
      if (filters.category && inc.category_id !== Number(filters.category)) return false;
      if (filters.status && inc.status !== filters.status) return false;
      if (filters.severity && inc.severity !== filters.severity) return false;
      if (filters.search && !inc.description.toLowerCase().includes(filters.search.toLowerCase())) return false;
      return true;
    });
  }, [mapIncidents, filters]);

  const clearFilters = () => {
    setFilters({
      category: null,
      status: null,
      severity: null,
      search: null,
      page: 1,
      pageSize: PAGE_SIZE,
    });
  };

  const hasActiveFilters = filters.category || filters.status || filters.severity || filters.search;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">{t('map.title')}</h1>
        <p className="text-sm text-gray-500">{t('map.subtitle')}</p>
      </div>

      {/* View toggle */}
      <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
        <div className="inline-flex rounded-lg border border-gray-200 overflow-hidden">
          <button
            onClick={() => setViewMode('map')}
            className={`inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors ${
              viewMode === 'map' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
            aria-pressed={viewMode === 'map'}
          >
            <MapPin className="w-4 h-4" />
            {t('map.viewMap')}
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors ${
              viewMode === 'list' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
            aria-pressed={viewMode === 'list'}
          >
            <List className="w-4 h-4" />
            {t('map.viewList')}
          </button>
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          aria-expanded={showFilters}
        >
          <Filter className="w-4 h-4" />
          {language === 'te' ? 'ఫిల్టర్‌లు' : 'Filters'}
          {hasActiveFilters && (
            <span className="w-2 h-2 bg-blue-600 rounded-full" aria-label="Active filters" />
          )}
        </button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <FilterSelect
              label={t('map.filter.category')}
              value={filters.category ?? ''}
              onChange={(v) => setFilters((f) => ({ ...f, category: v ? Number(v) : null, page: 1 }))}
              options={[
                { value: '', label: t('map.filter.all') },
                ...(categories.data ?? []).map((c) => ({
                  value: String(c.id),
                  label: language === 'te' ? c.label_te : c.label_en,
                })),
              ]}
            />
            <FilterSelect
              label={t('map.filter.status')}
              value={filters.status ?? ''}
              onChange={(v) => setFilters((f) => ({ ...f, status: (v || null) as IncidentStatus | null, page: 1 }))}
              options={[
                { value: '', label: t('map.filter.all') },
                ...STATUS_ORDER.map((s) => ({
                  value: s,
                  label: language === 'te' ? STATUS_LABELS[s].te : STATUS_LABELS[s].en,
                })),
              ]}
            />
            <FilterSelect
              label={t('map.filter.severity')}
              value={filters.severity ?? ''}
              onChange={(v) => setFilters((f) => ({ ...f, severity: (v || null) as Severity | null, page: 1 }))}
              options={[
                { value: '', label: t('map.filter.all') },
                ...SEVERITY_LEVELS.map((s) => ({
                  value: s,
                  label: language === 'te' ? SEVERITY_LABELS[s].te : SEVERITY_LABELS[s].en,
                })),
              ]}
            />
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">{t('map.filter.search')}</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={filters.search ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value || null, page: 1 }))}
                  placeholder={t('map.filter.search.placeholder')}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="mt-3 inline-flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
            >
              <X className="w-4 h-4" />
              {t('map.filter.clear')}
            </button>
          )}
        </div>
      )}

      {/* Content */}
      {viewMode === 'map' ? (
        <MapView
          incidents={filteredMapIncidents}
          loading={mapLoading}
          error={mapError}
          onRetry={mapReload}
          selectedIncident={selectedIncident}
          onSelectIncident={setSelectedIncident}
          language={language}
          t={t}
        />
      ) : (
        <ListView
          data={listData}
          loading={listLoading}
          error={listError}
          onRetry={listReload}
          filters={filters}
          setFilters={setFilters}
          onSelectIncident={setSelectedIncident}
          language={language}
          t={t}
        />
      )}

      {/* Incident detail modal */}
      {selectedIncident && (
        <IncidentDetailModal
          incident={selectedIncident}
          language={language}
          onClose={() => setSelectedIncident(null)}
          t={t}
        />
      )}
    </div>
  );
}

function MapView({
  incidents,
  loading,
  error,
  onRetry,
  selectedIncident,
  onSelectIncident,
  language,
  t,
}: {
  incidents: Incident[];
  loading: boolean;
  error: Error | null;
  onRetry: () => void;
  selectedIncident: Incident | null;
  onSelectIncident: (inc: Incident) => void;
  language: 'en' | 'te';
  t: (key: import('@/lib/i18n').TranslationKey) => string;
}) {
  if (loading) return <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>;
  if (error) return <ErrorState message={t('map.error')} onRetry={onRetry} retryLabel={t('common.retry')} />;
  if (incidents.length === 0) return <EmptyState message={t('map.empty')} icon={MapPin} />;

  return (
    <div>
      {/* Map visualization (SVG-based, no external dependency) */}
      <div className="relative bg-gradient-to-br from-blue-50 to-cyan-50 border border-gray-200 rounded-xl overflow-hidden" style={{ minHeight: '400px' }}>
        <SimpleMapView incidents={incidents} onSelect={onSelectIncident} selectedId={selectedIncident?.id ?? null} language={language} />
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-gray-500">
        <span className="font-medium">{t('map.legend')}:</span>
        {SEVERITY_LEVELS.map((sev) => (
          <span key={sev} className="flex items-center gap-1.5">
            <span className={`w-3 h-3 rounded-full ${SEVERITY_COLORS[sev].dot}`} />
            {language === 'te' ? SEVERITY_LABELS[sev].te : SEVERITY_LABELS[sev].en}
          </span>
        ))}
      </div>

      <p className="text-xs text-gray-400 mt-3">
        {t('map.lastUpdated')}: {formatRelativeTime(new Date().toISOString(), language)}
      </p>
    </div>
  );
}

function SimpleMapView({
  incidents,
  onSelect,
  selectedId,
  language,
}: {
  incidents: Incident[];
  onSelect: (inc: Incident) => void;
  selectedId: string | null;
  language: 'en' | 'te';
}) {
  // Find bounds
  const lats = incidents.map((i) => i.latitude).filter(Boolean) as number[];
  const lngs = incidents.map((i) => i.longitude).filter(Boolean) as number[];

  if (lats.length === 0) {
    return (
      <div className="flex items-center justify-center py-20 text-gray-400 text-sm">
        {language === 'te' ? 'పటంపై చూపించడానికి స్థానం డేటా లేదు' : 'No location data to display on map'}
      </div>
    );
  }

  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const latRange = maxLat - minLat || 0.01;
  const lngRange = maxLng - minLng || 0.01;

  const padding = 40;
  const width = 800;
  const height = 400;

  const projectX = (lng: number) => padding + ((lng - minLng) / lngRange) * (width - 2 * padding);
  const projectY = (lat: number) => height - padding - ((lat - minLat) / latRange) * (height - 2 * padding);

  return (
    <div className="relative w-full" role="application" aria-label={language === 'te' ? 'ప్రమాదాల పటం' : 'Incident map'}>
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto" style={{ minHeight: '400px' }}>
        {/* Grid lines */}
        {[0.25, 0.5, 0.75].map((p) => (
          <g key={p}>
            <line x1={padding} y1={height * p} x2={width - padding} y2={height * p} stroke="#dbe1e6" strokeWidth="1" strokeDasharray="4 4" />
            <line x1={width * p} y1={padding} x2={width * p} y2={height - padding} stroke="#dbe1e6" strokeWidth="1" strokeDasharray="4 4" />
          </g>
        ))}
        {/* Border */}
        <rect x={padding} y={padding} width={width - 2 * padding} height={height - 2 * padding} fill="none" stroke="#cbd5e1" strokeWidth="1.5" rx="8" />

        {/* Incidents */}
        {incidents.map((inc) => {
          if (inc.latitude == null || inc.longitude == null) return null;
          const x = projectX(inc.longitude);
          const y = projectY(inc.latitude);
          const isSelected = inc.id === selectedId;
          const colors = SEVERITY_COLORS[inc.severity];
          return (
            <g key={inc.id}>
              <circle
                cx={x}
                cy={y}
                r={isSelected ? 12 : 8}
                fill={colors.dot}
                stroke="white"
                strokeWidth="2"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => onSelect(inc)}
                role="button"
                tabIndex={0}
                aria-label={`${language === 'te' ? inc.category?.label_te : inc.category?.label_en} - ${inc.severity}`}
              >
                <title>{inc.description.slice(0, 80)}</title>
              </circle>
              {isSelected && (
                <circle cx={x} cy={y} r="18" fill="none" stroke={colors.dot} strokeWidth="2" opacity="0.4">
                  <animate attributeName="r" from="12" to="22" dur="1s" repeatCount="indefinite" />
                  <animate attributeName="opacity" from="0.6" to="0" dur="1s" repeatCount="indefinite" />
                </circle>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function ListView({
  data,
  loading,
  error,
  onRetry,
  filters,
  setFilters,
  onSelectIncident,
  language,
  t,
}: {
  data: { incidents: Incident[]; total: number } | null;
  loading: boolean;
  error: Error | null;
  onRetry: () => void;
  filters: IncidentFilters;
  setFilters: React.Dispatch<React.SetStateAction<IncidentFilters>>;
  onSelectIncident: (inc: Incident) => void;
  language: 'en' | 'te';
  t: (key: import('@/lib/i18n').TranslationKey) => string;
}) {
  if (loading && !data) return <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>;
  if (error) return <ErrorState message={t('list.error')} onRetry={onRetry} retryLabel={t('common.retry')} />;
  if (!data || data.incidents.length === 0) return <EmptyState message={t('list.empty')} icon={List} />;

  const hasMore = data.incidents.length < data.total;

  return (
    <div>
      <p className="text-sm text-gray-500 mb-4">
        {data.total} {t('list.results')}
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.incidents.map((inc) => (
          <IncidentCard
            key={inc.id}
            incident={inc}
            language={language}
            onClick={() => onSelectIncident(inc)}
          />
        ))}
      </div>
      {hasMore && (
        <div className="mt-6 text-center">
          <button
            onClick={() => setFilters((f) => ({ ...f, page: f.page + 1 }))}
            disabled={loading}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors disabled:opacity-50"
          >
            {loading ? <LoadingSpinner size="sm" /> : null}
            {t('list.loadMore')}
          </button>
        </div>
      )}
    </div>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function IncidentDetailModal({
  incident,
  language,
  onClose,
  t,
}: {
  incident: Incident;
  language: 'en' | 'te';
  onClose: () => void;
  t: (key: import('@/lib/i18n').TranslationKey) => string;
}) {
  const categoryLabel =
    language === 'te' ? incident.category?.label_te : incident.category?.label_en;
  const CategoryIcon = categoryIcons[incident.category?.icon ?? 'AlertTriangle'] ?? AlertTriangle;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={language === 'te' ? 'సంఘటన వివరాలు' : 'Incident details'}
    >
      <div
        className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">
            {language === 'te' ? 'సంఘటన వివరాలు' : 'Incident Details'}
          </h2>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600 rounded-md"
            aria-label={t('common.close')}
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
              <CategoryIcon className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">{categoryLabel}</p>
              <p className="text-xs text-gray-400">{formatRelativeTime(incident.created_at, language)}</p>
            </div>
          </div>

          {incident.image_url && (
            <img
              src={incident.image_url}
              alt="Incident"
              className="w-full rounded-lg border border-gray-200"
            />
          )}

          <div>
            <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.description')}</p>
            <p className="text-sm text-gray-700 leading-relaxed">{incident.description}</p>
          </div>

          {incident.location_text && (
            <div>
              <p className="text-xs font-medium text-gray-500 mb-1">{t('myReports.location')}</p>
              <p className="text-sm text-gray-700 flex items-center gap-1">
                <MapPin className="w-4 h-4 text-gray-400" />
                {incident.location_text}
              </p>
            </div>
          )}

          {incident.latitude != null && incident.longitude != null && (
            <p className="text-xs text-gray-400">
              📍 {incident.latitude.toFixed(5)}, {incident.longitude.toFixed(5)}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
