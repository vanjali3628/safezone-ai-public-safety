import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

type Page = 'home' | 'report' | 'map' | 'emergency' | 'assistant' | 'track';

type RouterContextValue = {
  currentPage: Page;
  navigate: (page: Page) => void;
  trackCode: string | null;
  setTrackCode: (code: string | null) => void;
};

const RouterContext = createContext<RouterContextValue | null>(null);

export function RouterProvider({ children }: { children: ReactNode }) {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [trackCode, setTrackCode] = useState<string | null>(null);

  const navigate = useCallback((page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <RouterContext.Provider value={{ currentPage, navigate, trackCode, setTrackCode }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter(): RouterContextValue {
  const ctx = useContext(RouterContext);
  if (!ctx) {
    throw new Error('useRouter must be used within RouterProvider');
  }
  return ctx;
}

export type { Page };
