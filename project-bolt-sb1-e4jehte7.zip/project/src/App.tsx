import { LanguageProvider } from '@/contexts/LanguageContext';
import { ToastProvider } from '@/contexts/ToastContext';
import { RouterProvider, useRouter } from '@/contexts/RouterContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { DisclaimerBanner, EmergencyCallBar } from '@/components/DisclaimerBanner';
import { HomePage } from '@/pages/HomePage';
import { ReportPage } from '@/pages/ReportPage';
import { MapPage } from '@/pages/MapPage';
import { EmergencyPage } from '@/pages/EmergencyPage';
import { AssistantPage } from '@/pages/AssistantPage';
import { TrackPage } from '@/pages/TrackPage';

function AppContent() {
  const { currentPage } = useRouter();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <DisclaimerBanner />
      <Header />
      <main className="flex-1 pt-16 pb-16 md:pb-0">
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'report' && <ReportPage />}
        {currentPage === 'map' && <MapPage />}
        {currentPage === 'emergency' && <EmergencyPage />}
        {currentPage === 'assistant' && <AssistantPage />}
        {currentPage === 'track' && <TrackPage />}
      </main>
      <Footer />
      <EmergencyCallBar />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <ToastProvider>
        <RouterProvider>
          <AppContent />
        </RouterProvider>
      </ToastProvider>
    </LanguageProvider>
  );
}
