import { supabase } from '@/lib/supabase';
import { generateTrackingCode } from '@/lib/trackingCode';
import { sanitizeText, sanitizeContact, sanitizeLocationText } from '@/lib/validation';
import { classifySeverity } from '@/lib/classification';
import type {
  Incident,
  IncidentCategory,
  IncidentEvent,
  IncidentReportInput,
  EmergencyContact,
  IncidentFilters,
} from '@/types';
import { PAGE_SIZE } from '@/lib/constants';

export async function fetchCategories(): Promise<IncidentCategory[]> {
  const { data, error } = await supabase
    .from('incident_categories')
    .select('*')
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function fetchEmergencyContacts(): Promise<EmergencyContact[]> {
  const { data, error } = await supabase
    .from('emergency_contacts')
    .select('*')
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function fetchPublicIncidents(filters: IncidentFilters): Promise<{
  incidents: Incident[];
  total: number;
}> {
  let query = supabase
    .from('incidents')
    .select(
      'id, tracking_code, category_id, description, latitude, longitude, location_text, severity, status, image_url, is_public, created_at, updated_at, resolved_at, category:incident_categories(*)',
      { count: 'exact' },
    )
    .eq('is_public', true)
    .order('created_at', { ascending: false });

  if (filters.category) {
    query = query.eq('category_id', filters.category);
  }
  if (filters.status) {
    query = query.eq('status', filters.status);
  }
  if (filters.severity) {
    query = query.eq('severity', filters.severity);
  }
  if (filters.search) {
    query = query.ilike('description', `%${filters.search}%`);
  }

  const from = (filters.page - 1) * filters.pageSize;
  const to = from + filters.pageSize - 1;
  query = query.range(from, to);

  const { data, error, count } = await query;

  if (error) throw error;

  return {
    incidents: (data ?? []) as unknown as Incident[],
    total: count ?? 0,
  };
}

export async function fetchAllPublicIncidentsForMap(): Promise<Incident[]> {
  const { data, error } = await supabase
    .from('incidents')
    .select(
      'id, tracking_code, category_id, description, latitude, longitude, location_text, severity, status, image_url, is_public, created_at, updated_at, resolved_at, category:incident_categories(*)',
    )
    .eq('is_public', true)
    .not('latitude', 'is', null)
    .not('longitude', 'is', null)
    .order('created_at', { ascending: false })
    .limit(200);

  if (error) throw error;
  return (data ?? []) as unknown as Incident[];
}

export async function submitIncidentReport(
  input: IncidentReportInput,
  categories: IncidentCategory[],
): Promise<{ trackingCode: string; incident: Incident }> {
  const trackingCode = generateTrackingCode();

  const category = categories.find((c) => c.id === input.category_id);
  const finalSeverity = classifySeverity(input.description, category?.default_severity ?? 'medium');

  const insertData = {
    tracking_code: trackingCode,
    category_id: input.category_id,
    description: sanitizeText(input.description),
    latitude: input.latitude,
    longitude: input.longitude,
    location_text: input.location_text ? sanitizeLocationText(input.location_text) : null,
    severity: finalSeverity,
    reporter_contact: input.reporter_contact ? sanitizeContact(input.reporter_contact) : null,
    image_url: input.image_url,
    is_public: input.is_public,
  };

  const { data, error } = await supabase
    .from('incidents')
    .insert(insertData)
    .select(
      'id, tracking_code, category_id, description, latitude, longitude, location_text, severity, status, image_url, is_public, created_at, updated_at, resolved_at',
    )
    .single();

  if (error) throw error;

  // Insert audit event
  await supabase.from('incident_events').insert({
    incident_id: data.id,
    event_type: 'created',
    old_status: null,
    new_status: 'reported',
    note: 'Report submitted by citizen',
  });

  return { trackingCode, incident: data as Incident };
}

export async function fetchIncidentByTrackingCode(code: string): Promise<{
  incident: Incident | null;
  events: IncidentEvent[];
}> {
  const { data: incident, error: incError } = await supabase
    .from('incidents')
    .select(
      'id, tracking_code, category_id, description, latitude, longitude, location_text, severity, status, image_url, is_public, created_at, updated_at, resolved_at, category:incident_categories(*)',
    )
    .eq('tracking_code', code)
    .maybeSingle();

  if (incError) throw incError;
  if (!incident) return { incident: null, events: [] };

  const { data: events, error: evError } = await supabase
    .from('incident_events')
    .select('*')
    .eq('incident_id', incident.id)
    .order('created_at', { ascending: true });

  if (evError) throw evError;

  return {
    incident: incident as unknown as Incident,
    events: (events ?? []) as IncidentEvent[],
  };
}

export async function checkDuplicateReport(
  description: string,
  latitude: number | null,
  longitude: number | null,
): Promise<boolean> {
  let query = supabase
    .from('incidents')
    .select('description, latitude, longitude, created_at')
    .order('created_at', { ascending: false })
    .limit(20);

  if (latitude != null && longitude != null) {
    query = query
      .not('latitude', 'is', null)
      .not('longitude', 'is', null);
  }

  const { data, error } = await query;

  if (error) return false;

  const { detectDuplicate } = await import('@/lib/classification');
  return detectDuplicate(description, { lat: latitude, lng: longitude }, data ?? []);
}

export { PAGE_SIZE };
