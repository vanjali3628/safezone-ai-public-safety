import type { Severity } from '@/types';

const HIGH_RISK_KEYWORDS = [
  'fire', 'blaze', 'smoke', 'burning', 'flames',
  'flood', 'drowning', 'electrocution', 'shock', 'collapsed',
  'explosion', 'blast', 'gas leak', 'structural',
  'assault', 'attack', 'stabbed', 'shooting', 'weapon',
  'accident', 'blood', 'unconscious', 'heart attack',
  'అగ్ని', 'వరద', 'విద్యుత్', 'ప్రమాదం', 'దాడి', 'పేలుడు',
];

const MEDIUM_RISK_KEYWORDS = [
  'pothole', 'crack', 'debris', 'broken', 'damaged',
  'waterlogging', 'water logging', 'stray', 'dog', 'monkey',
  'garbage', 'sewage', 'overflow', 'leak', 'dark street',
  'no light', 'streetlight', 'crack in road',
  'గుంత', 'చెత్త', 'కుక్క', 'కోతి', 'నీటి నిల్వ', 'లీక్',
];

const LOW_RISK_KEYWORDS = [
  'noise', 'graffiti', 'litter', 'minor', 'small', 'nuisance',
  'parking', 'sidewalk', 'signage',
  'శబ్దం', 'చిన్న', 'పార్కింగ్',
];

export function classifySeverity(description: string, defaultSeverity: Severity): Severity {
  const lower = description.toLowerCase();

  for (const keyword of HIGH_RISK_KEYWORDS) {
    if (lower.includes(keyword.toLowerCase())) {
      return 'critical';
    }
  }

  for (const keyword of MEDIUM_RISK_KEYWORDS) {
    if (lower.includes(keyword.toLowerCase())) {
      return 'high';
    }
  }

  for (const keyword of LOW_RISK_KEYWORDS) {
    if (lower.includes(keyword.toLowerCase())) {
      return 'low';
    }
  }

  return defaultSeverity;
}

export function detectDuplicate(
  newDescription: string,
  newLocation: { lat: number | null; lng: number | null },
  existingIncidents: { description: string; latitude: number | null; longitude: number | null; created_at: string }[],
  timeWindowHours = 24,
): boolean {
  const now = Date.now();
  const windowMs = timeWindowHours * 60 * 60 * 1000;

  const normalize = (text: string) => text.toLowerCase().trim().replace(/\s+/g, ' ');

  const newDesc = normalize(newDescription);

  for (const incident of existingIncidents) {
    const createdTime = new Date(incident.created_at).getTime();
    if (now - createdTime > windowMs) continue;

    const existingDesc = normalize(incident.description);

    // Check for very similar descriptions
    if (newDesc === existingDesc) return true;

    // Check for proximity-based duplicates (within ~100m)
    if (
      newLocation.lat != null &&
      newLocation.lng != null &&
      incident.latitude != null &&
      incident.longitude != null
    ) {
      const distance = haversineDistance(
        newLocation.lat,
        newLocation.lng,
        incident.latitude,
        incident.longitude,
      );
      if (distance < 0.1 && newDesc === existingDesc) return true;
    }
  }

  return false;
}

function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}
