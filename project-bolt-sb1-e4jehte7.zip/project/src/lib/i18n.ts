import type { Language } from '@/types';

export type TranslationKey =
  | 'appName'
  | 'tagline'
  | 'nav.home'
  | 'nav.report'
  | 'nav.map'
  | 'nav.emergency'
  | 'nav.assistant'
  | 'nav.myReports'
  | 'nav.trackReport'
  | 'nav.signOut'
  | 'hero.title'
  | 'hero.subtitle'
  | 'hero.cta.report'
  | 'hero.cta.viewMap'
  | 'hero.cta.emergency'
  | 'disclaimer'
  | 'report.title'
  | 'report.subtitle'
  | 'report.category'
  | 'report.category.placeholder'
  | 'report.description'
  | 'report.description.placeholder'
  | 'report.description.help'
  | 'report.severity'
  | 'report.location'
  | 'report.location.placeholder'
  | 'report.location.help'
  | 'report.useMyLocation'
  | 'report.contact'
  | 'report.contact.placeholder'
  | 'report.contact.help'
  | 'report.image'
  | 'report.image.help'
  | 'report.image.button'
  | 'report.public'
  | 'report.public.help'
  | 'report.submit'
  | 'report.submitting'
  | 'report.success'
  | 'report.success.trackingCode'
  | 'report.success.note'
  | 'report.error'
  | 'report.duplicate.warning'
  | 'report.new'
  | 'map.title'
  | 'map.subtitle'
  | 'map.loading'
  | 'map.empty'
  | 'map.error'
  | 'map.viewList'
  | 'map.viewMap'
  | 'map.filter.category'
  | 'map.filter.status'
  | 'map.filter.severity'
  | 'map.filter.search'
  | 'map.filter.search.placeholder'
  | 'map.filter.all'
  | 'map.filter.clear'
  | 'map.legend'
  | 'map.lastUpdated'
  | 'list.title'
  | 'list.empty'
  | 'list.loadMore'
  | 'list.loading'
  | 'list.error'
  | 'list.retry'
  | 'list.reportedOn'
  | 'list.viewDetails'
  | 'list.results'
  | 'list.noResults'
  | 'emergency.title'
  | 'emergency.subtitle'
  | 'emergency.callNow'
  | 'emergency.safetyTips'
  | 'emergency.viewTips'
  | 'assistant.title'
  | 'assistant.subtitle'
  | 'assistant.placeholder'
  | 'assistant.send'
  | 'assistant.disclaimer'
  | 'assistant.emergency.warning'
  | 'assistant.empty'
  | 'assistant.loading'
  | 'myReports.title'
  | 'myReports.subtitle'
  | 'myReports.enterCode'
  | 'myReports.code.placeholder'
  | 'myReports.find'
  | 'myReports.notFound'
  | 'myReports.statusHistory'
  | 'myReports.reportedOn'
  | 'myReports.lastUpdated'
  | 'myReports.description'
  | 'myReports.location'
  | 'myReports.severity'
  | 'myReports.category'
  | 'myReports.trackAnother'
  | 'myReports.loading'
  | 'myReports.error'
  | 'myReports.retry'
  | 'common.loading'
  | 'common.error'
  | 'common.retry'
  | 'common.close'
  | 'common.back'
  | 'common.yes'
  | 'common.no'
  | 'common.optional'
  | 'common.sample'
  | 'common.reportNow'
  | 'footer.about'
  | 'footer.disclaimer'
  | 'footer.emergencyCall'
  | 'footer.copyright'
  | 'footer.sampleNote'
  | 'lang.toggle'
  | 'lang.english'
  | 'lang.telugu';

export const translations: Record<Language, Record<TranslationKey, string>> = {
  en: {
    appName: 'SafeZone AI',
    tagline: 'Community Safety Platform',
    'nav.home': 'Home',
    'nav.report': 'Report Hazard',
    'nav.map': 'Safety Map',
    'nav.emergency': 'Emergency',
    'nav.assistant': 'Safety Assistant',
    'nav.myReports': 'Track Report',
    'nav.trackReport': 'Track Report',
    'nav.signOut': 'Sign Out',
    'hero.title': 'Report Hazards. Stay Informed. Stay Safe.',
    'hero.subtitle': 'A community-driven platform for reporting public safety hazards, accessing emergency guidance, and tracking resolutions — in English and Telugu.',
    'hero.cta.report': 'Report a Hazard',
    'hero.cta.viewMap': 'View Safety Map',
    'hero.cta.emergency': 'Emergency Contacts',
    disclaimer: 'Community reports are NOT automatically verified and do not replace emergency services. For emergencies, always call 112.',
    'report.title': 'Report a Hazard',
    'report.subtitle': 'Help your community by reporting public safety hazards. No account needed.',
    'report.category': 'Hazard Category',
    'report.category.placeholder': 'Select a category',
    'report.description': 'Description',
    'report.description.placeholder': 'Describe the hazard in detail (what, where, when)...',
    'report.description.help': 'Provide at least 10 characters. Do not include personal information about others.',
    'report.severity': 'Severity Level',
    'report.location': 'Location (optional)',
    'report.location.placeholder': 'e.g., Near Bus Stand, Main Road...',
    'report.location.help': 'Provide a nearby landmark or address. You can also use your current location.',
    'report.useMyLocation': 'Use My Current Location',
    'report.contact': 'Your Contact (optional)',
    'report.contact.placeholder': 'Phone or email (optional, never shown publicly)',
    'report.contact.help': 'Only used if authorities need to verify your report. Never displayed publicly.',
    'report.image': 'Photo (optional)',
    'report.image.help': 'JPG or PNG, max 5MB. Photos help authorities assess the hazard.',
    'report.image.button': 'Upload Photo',
    'report.public': 'Show on public map',
    'report.public.help': 'Public reports help others stay informed. Your contact info is never shown.',
    'report.submit': 'Submit Report',
    'report.submitting': 'Submitting...',
    'report.success': 'Report submitted successfully!',
    'report.success.trackingCode': 'Your tracking code:',
    'report.success.note': 'Save this code to track your report status. You can also find it on the Track Report page.',
    'report.error': 'Failed to submit report. Please try again.',
    'report.duplicate.warning': 'A similar report may already exist nearby. You can still submit — duplicates help confirm the hazard.',
    'report.new': 'Report Another',
    'map.title': 'Safety Map',
    'map.subtitle': 'View reported hazards in your area. Community reports are not automatically verified.',
    'map.loading': 'Loading map...',
    'map.empty': 'No incidents to display.',
    'map.error': 'Failed to load incidents.',
    'map.viewList': 'View as List',
    'map.viewMap': 'View as Map',
    'map.filter.category': 'Category',
    'map.filter.status': 'Status',
    'map.filter.severity': 'Severity',
    'map.filter.search': 'Search',
    'map.filter.search.placeholder': 'Search descriptions...',
    'map.filter.all': 'All',
    'map.filter.clear': 'Clear Filters',
    'map.legend': 'Legend',
    'map.lastUpdated': 'Last updated',
    'list.title': 'Incident List',
    'list.empty': 'No incidents found matching your filters.',
    'list.loadMore': 'Load More',
    'list.loading': 'Loading...',
    'list.error': 'Failed to load incidents.',
    'list.retry': 'Retry',
    'list.reportedOn': 'Reported',
    'list.viewDetails': 'View Details',
    'list.results': 'results',
    'list.noResults': 'No results found',
    'emergency.title': 'Emergency Contacts & Safety Guidance',
    'emergency.subtitle': 'Verified emergency numbers for India. Call these numbers directly in emergencies.',
    'emergency.callNow': 'Call',
    'emergency.safetyTips': 'Safety Tips',
    'emergency.viewTips': 'View Safety Tips',
    'assistant.title': 'Safety Assistant',
    'assistant.subtitle': 'Get cautious, practical safety guidance. Not a substitute for emergency services.',
    'assistant.placeholder': 'Describe your safety concern...',
    'assistant.send': 'Ask',
    'assistant.disclaimer': 'This assistant provides general safety guidance only. For emergencies, call 112. It does not dispatch services or provide medical/legal advice.',
    'assistant.emergency.warning': 'EMERGENCY: Call 112 immediately',
    'assistant.empty': 'Ask about fire safety, floods, road hazards, crime, electrical hazards, and more.',
    'assistant.loading': 'Generating response...',
    'myReports.title': 'Track Your Report',
    'myReports.subtitle': 'Enter your tracking code to view your report status and history.',
    'myReports.enterCode': 'Enter Tracking Code',
    'myReports.code.placeholder': 'e.g., SZ-A8F3K2AB',
    'myReports.find': 'Find Report',
    'myReports.notFound': 'No report found with that tracking code. Please check and try again.',
    'myReports.statusHistory': 'Status History',
    'myReports.reportedOn': 'Reported on',
    'myReports.lastUpdated': 'Last updated',
    'myReports.description': 'Description',
    'myReports.location': 'Location',
    'myReports.severity': 'Severity',
    'myReports.category': 'Category',
    'myReports.trackAnother': 'Track Another Report',
    'myReports.loading': 'Loading...',
    'myReports.error': 'Failed to load report. Please try again.',
    'myReports.retry': 'Retry',
    'common.loading': 'Loading...',
    'common.error': 'Something went wrong',
    'common.retry': 'Retry',
    'common.close': 'Close',
    'common.back': 'Back',
    'common.yes': 'Yes',
    'common.no': 'No',
    'common.optional': 'optional',
    'common.sample': 'Sample',
    'common.reportNow': 'Report Now',
    'footer.about': 'About',
    'footer.disclaimer': 'Disclaimer',
    'footer.emergencyCall': 'Emergency: 112',
    'footer.copyright': 'SafeZone AI — Community Safety Platform',
    'footer.sampleNote': 'Some data shown is sample data for demonstration.',
    'lang.toggle': 'తెలుగు',
    'lang.english': 'English',
    'lang.telugu': 'తెలుగు',
  },
  te: {
    appName: 'SafeZone AI',
    tagline: 'కమ్యూనిటీ భద్రతా వేదిక',
    'nav.home': 'హోమ్',
    'nav.report': 'ప్రమాదం నివేదించండి',
    'nav.map': 'భద్రతా పటం',
    'nav.emergency': 'అత్యవసరం',
    'nav.assistant': 'భద్రతా సహాయకుడు',
    'nav.myReports': 'నివేదిక ట్రాక్',
    'nav.trackReport': 'నివేదిక ట్రాక్',
    'nav.signOut': 'సైన్ అవుట్',
    'hero.title': 'ప్రమాదాలు నివేదించండి. సమాచారం పొందండి. సురక్షితంగా ఉండండి.',
    'hero.subtitle': 'ప్రజా భద్రతా ప్రమాదాలను నివేదించడం, అత్యవసర మార్గదర్శకత్వం పొందడం మరియు పరిష్కారాలను ట్రాక్ చేయడం కోసం కమ్యూనిటీ ఆధారిత వేదిక — ఆంగ్లం మరియు తెలుగులో.',
    'hero.cta.report': 'ప్రమాదం నివేదించండి',
    'hero.cta.viewMap': 'భద్రతా పటం',
    'hero.cta.emergency': 'అత్యవసర సంఖ్యలు',
    disclaimer: 'కమ్యూనిటీ నివేదికలు స్వయంచాలకంగా ధృవీకరించబడవు మరియు అత్యవసర సేవలను భర్తీ చేయవు. అత్యవసరాల కోసం ఎల్లప్పుడూ 112 కు కాల్ చేయండి.',
    'report.title': 'ప్రమాదం నివేదించండి',
    'report.subtitle': 'మీ కమ్యూనిటీకి సహాయం చేయండి. ఖాతా అవసరం లేదు.',
    'report.category': 'ప్రమాద వర్గం',
    'report.category.placeholder': 'వర్గాన్ని ఎంచుకండి',
    'report.description': 'వివరణ',
    'report.description.placeholder': 'ప్రమాదాన్ని వివరంగా చెప్పండి (ఏమి, ఎక్కడ, ఎప్పుడు)...',
    'report.description.help': 'కనీసం 10 అక్షరాలు ఇవ్వండి. ఇతరుల వ్యక్తిగత సమాచారం చేర్చవద్దు.',
    'report.severity': 'తీవ్రత స్థాయి',
    'report.location': 'స్థానం (ఐచ్ఛిక)',
    'report.location.placeholder': 'ఉదా., బస్ స్టాండ్ సమీపంలో, ప్రధాన రహదారి...',
    'report.location.help': 'సమీపంలోని మైలురాయి లేదా చిరునామా ఇవ్వండి. మీ ప్రస్తుత స్థానాన్ని కూడా ఉపయోగించవచ్చు.',
    'report.useMyLocation': 'నా ప్రస్తుత స్థానాన్ని ఉపయోగించు',
    'report.contact': 'మీ సంప్రదింపు (ఐచ్ఛిక)',
    'report.contact.placeholder': 'ఫోన్ లేదా ఇమెయిల్ (ఐచ్ఛిక, బహిరంగగా చూపబడదు)',
    'report.contact.help': 'అధికారులు మీ నివేదికను ధృవీకరించాలంటే మాత్రమే ఉపయోగిస్తారు. ఎప్పుడూ బహిరంగగా చూపబడదు.',
    'report.image': 'ఫోటో (ఐచ్ఛిక)',
    'report.image.help': 'JPG లేదా PNG, గరిష్ట 5MB. ఫోటోలు అధికారులకు సహాయపడతాయి.',
    'report.image.button': 'ఫోటో అప్‌లోడ్ చేయండి',
    'report.public': 'బహిరంగ పటంపై చూపించు',
    'report.public.help': 'బహిరంగ నివేదికలు ఇతరులకు సహాయపడతాయి. మీ సంప్రదింపు ఎప్పుడూ చూపబడదు.',
    'report.submit': 'నివేదిక సమర్పించండి',
    'report.submitting': 'సమర్పిస్తోంది...',
    'report.success': 'నివేదిక విజయవంతంగా సమర్పించబడింది!',
    'report.success.trackingCode': 'మీ ట్రాకింగ్ కోడ్:',
    'report.success.note': 'మీ నివేదిక స్థితిని ట్రాక్ చేయడానికి ఈ కోడ్‌ను సేవ్ చేయండి.',
    'report.error': 'నివేదిక సమర్పించడం విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.',
    'report.duplicate.warning': 'ఇలాంటి నివేదిక ఇప్పటికే ఉండవచ్చు. మీరు ఇప్పటికీ సమర్పించవచ్చు.',
    'report.new': 'మరొకటి నివేదించండి',
    'map.title': 'భద్రతా పటం',
    'map.subtitle': 'మీ ప్రాంతంలో నివేదించబడిన ప్రమాదాలను చూడండి. కమ్యూనిటీ నివేదికలు స్వయంచాలకంగా ధృవీకరించబడవు.',
    'map.loading': 'పటం లోడ్ అవుతోంది...',
    'map.empty': 'ప్రదర్శించడానికి సంఘటనలు లేవు.',
    'map.error': 'సంఘటనలు లోడ్ చేయడం విఫలమైంది.',
    'map.viewList': 'జాబితాగా చూడండి',
    'map.viewMap': 'పటంగా చూడండి',
    'map.filter.category': 'వర్గం',
    'map.filter.status': 'స్థితి',
    'map.filter.severity': 'తీవ్రత',
    'map.filter.search': 'వెతకండి',
    'map.filter.search.placeholder': 'వివరణలలో వెతకండి...',
    'map.filter.all': 'అన్నీ',
    'map.filter.clear': 'ఫిల్టర్‌లను తొలగించు',
    'map.legend': 'పురాణ చిహ్నం',
    'map.lastUpdated': 'చివరిగా నవీకరించబడింది',
    'list.title': 'సంఘటనల జాబితా',
    'list.empty': 'మీ ఫిల్టర్‌లకు సరిపోలే సంఘటనలు లేవు.',
    'list.loadMore': 'మరిన్ని లోడ్ చేయండి',
    'list.loading': 'లోడ్ అవుతోంది...',
    'list.error': 'సంఘటనలు లోడ్ చేయడం విఫలమైంది.',
    'list.retry': 'మళ్లీ ప్రయత్నించు',
    'list.reportedOn': 'నివేదించబడింది',
    'list.viewDetails': 'వివరాలు చూడండి',
    'list.results': 'ఫలితాలు',
    'list.noResults': 'ఫలితాలు లేవు',
    'emergency.title': 'అత్యవసర సంఖ్యలు & భద్రతా మార్గదర్శకత్వం',
    'emergency.subtitle': 'భారతదేశం కోసం ధృవీకరించబడిన అత్యవసర నంబర్‌లు. అత్యవసరాలలో ఈ నంబర్‌లకు నేరుగా కాల్ చేయండి.',
    'emergency.callNow': 'కాల్ చేయండి',
    'emergency.safetyTips': 'భద్రతా చిట్కాలు',
    'emergency.viewTips': 'భద్రతా చిట్కాలు చూడండి',
    'assistant.title': 'భద్రతా సహాయకుడు',
    'assistant.subtitle': 'జాగ్రత్త, ఆచరణీయ భద్రతా మార్గదర్శకత్వం పొందండి. అత్యవసర సేవలకు ప్రత్యామ్నాయం కాదు.',
    'assistant.placeholder': 'మీ భద్రతా ఆందోళనను వివరించండి...',
    'assistant.send': 'అడగండి',
    'assistant.disclaimer': 'ఈ సహాయకుడు సాధారణ భద్రతా మార్గదర్శకత్వాన్ని మాత్రమే ఇస్తాడు. అత్యవసరాల కోసం 112 కు కాల్ చేయండి.',
    'assistant.emergency.warning': 'అత్యవసరం: వెంటనే 112 కు కాల్ చేయండి',
    'assistant.empty': 'అగ్ని భద్రత, వరదలు, రహదారి ప్రమాదాలు, నేరం, విద్యుత్ ప్రమాదాల గురించి అడగండి.',
    'assistant.loading': 'స్పందన తయారు చేస్తోంది...',
    'myReports.title': 'మీ నివేదిక ట్రాక్ చేయండి',
    'myReports.subtitle': 'మీ నివేదిక స్థితి మరియు చరిత్రను చూడటానికి మీ ట్రాకింగ్ కోడ్‌ను నమోదు చేయండి.',
    'myReports.enterCode': 'ట్రాకింగ్ కోడ్ నమోదు చేయండి',
    'myReports.code.placeholder': 'ఉదా., SZ-A8F3K2AB',
    'myReports.find': 'నివేదిక కనుగొను',
    'myReports.notFound': 'ఆ ట్రాకింగ్ కోడ్‌తో నివేదిక కనుగొనబడలేదు. దయచేసి తనిఖీ చేసి మళ్లీ ప్రయత్నించండి.',
    'myReports.statusHistory': 'స్థితి చరిత్ర',
    'myReports.reportedOn': 'నివేదించబడిన తేదీ',
    'myReports.lastUpdated': 'చివరి నవీకరణ',
    'myReports.description': 'వివరణ',
    'myReports.location': 'స్థానం',
    'myReports.severity': 'తీవ్రత',
    'myReports.category': 'వర్గం',
    'myReports.trackAnother': 'మరొక నివేదిక ట్రాక్ చేయండి',
    'myReports.loading': 'లోడ్ అవుతోంది...',
    'myReports.error': 'నివేదిక లోడ్ చేయడం విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.',
    'myReports.retry': 'మళ్లీ ప్రయత్నించు',
    'common.loading': 'లోడ్ అవుతోంది...',
    'common.error': 'ఏదో తప్పు జరిగింది',
    'common.retry': 'మళ్లీ ప్రయత్నించు',
    'common.close': 'మూసివేయి',
    'common.back': 'వెనుకకు',
    'common.yes': 'అవును',
    'common.no': 'కాదు',
    'common.optional': 'ఐచ్ఛిక',
    'common.sample': 'నమూనా',
    'common.reportNow': 'ఇప్పుడే నివేదించండి',
    'footer.about': 'గురించి',
    'footer.disclaimer': 'హామీ',
    'footer.emergencyCall': 'అత్యవసరం: 112',
    'footer.copyright': 'SafeZone AI — కమ్యూనిటీ భద్రతా వేదిక',
    'footer.sampleNote': 'ప్రదర్శించబడిన కొన్ని డేటా నమూనా డేటా.',
    'lang.toggle': 'English',
    'lang.english': 'English',
    'lang.telugu': 'తెలుగు',
  },
};
