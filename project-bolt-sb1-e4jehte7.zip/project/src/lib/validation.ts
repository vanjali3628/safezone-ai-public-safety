import type { ValidationError, IncidentReportInput, Severity } from '@/types';
import {
  MAX_DESCRIPTION_LENGTH,
  MIN_DESCRIPTION_LENGTH,
  MAX_LOCATION_LENGTH,
  MAX_CONTACT_LENGTH,
  SEVERITY_LEVELS,
} from '@/lib/constants';

export function validateDescription(description: string): ValidationError | null {
  const trimmed = description.trim();
  if (trimmed.length === 0) {
    return {
      field: 'description',
      message: 'Please describe the hazard.',
      message_te: 'దయచేసి ప్రమాదాన్ని వివరించండి.',
    };
  }
  if (trimmed.length < MIN_DESCRIPTION_LENGTH) {
    return {
      field: 'description',
      message: `Description must be at least ${MIN_DESCRIPTION_LENGTH} characters.`,
      message_te: `వివరణ కనీసం ${MIN_DESCRIPTION_LENGTH} అక్షరాలు ఉండాలి.`,
    };
  }
  if (trimmed.length > MAX_DESCRIPTION_LENGTH) {
    return {
      field: 'description',
      message: `Description must not exceed ${MAX_DESCRIPTION_LENGTH} characters.`,
      message_te: `వివరణ ${MAX_DESCRIPTION_LENGTH} అక్షరాలను మించకూడదు.`,
    };
  }
  return null;
}

export function validateLocationText(locationText: string): ValidationError | null {
  if (locationText.length > MAX_LOCATION_LENGTH) {
    return {
      field: 'location_text',
      message: `Location must not exceed ${MAX_LOCATION_LENGTH} characters.`,
      message_te: `స్థానం ${MAX_LOCATION_LENGTH} అక్షరాలను మించకూడదు.`,
    };
  }
  return null;
}

export function validateContact(contact: string): ValidationError | null {
  if (contact.length > MAX_CONTACT_LENGTH) {
    return {
      field: 'reporter_contact',
      message: `Contact must not exceed ${MAX_CONTACT_LENGTH} characters.`,
      message_te: `సంప్రదింపు ${MAX_CONTACT_LENGTH} అక్షరాలను మించకూడదు.`,
    };
  }
  if (contact.length > 0 && !/^[a-zA-Z0-9\s@.+\-_/]+$/.test(contact)) {
    return {
      field: 'reporter_contact',
      message: 'Contact contains invalid characters.',
      message_te: 'సంప్రదింపులో చెల్లని అక్షరాలు ఉన్నాయి.',
    };
  }
  return null;
}

export function validateLatitude(lat: number): ValidationError | null {
  if (lat < -90 || lat > 90) {
    return {
      field: 'latitude',
      message: 'Latitude must be between -90 and 90.',
      message_te: 'అక్షాంశం -90 మరియు 90 మధ్య ఉండాలి.',
    };
  }
  return null;
}

export function validateLongitude(lng: number): ValidationError | null {
  if (lng < -180 || lng > 180) {
    return {
      field: 'longitude',
      message: 'Longitude must be between -180 and 180.',
      message_te: 'రేఖాంశం -180 మరియు 180 మధ్య ఉండాలి.',
    };
  }
  return null;
}

export function validateSeverity(severity: string): ValidationError | null {
  if (!SEVERITY_LEVELS.includes(severity as Severity)) {
    return {
      field: 'severity',
      message: 'Please select a valid severity level.',
      message_te: 'దయచేసి చెల్లుబాటు అయ్యే తీవ్రత స్థాయిని ఎంచుకండి.',
    };
  }
  return null;
}

export function validateCategoryId(categoryId: number): ValidationError | null {
  if (!Number.isInteger(categoryId) || categoryId < 1) {
    return {
      field: 'category_id',
      message: 'Please select a hazard category.',
      message_te: 'దయచేసి ప్రమాద వర్గాన్ని ఎంచుకండి.',
    };
  }
  return null;
}

export function validateIncidentReport(input: Partial<IncidentReportInput>): ValidationError[] {
  const errors: ValidationError[] = [];

  const descError = validateDescription(input.description ?? '');
  if (descError) errors.push(descError);

  const catError = validateCategoryId(input.category_id ?? 0);
  if (catError) errors.push(catError);

  const sevError = validateSeverity(input.severity ?? '');
  if (sevError) errors.push(sevError);

  if (input.location_text) {
    const locError = validateLocationText(input.location_text);
    if (locError) errors.push(locError);
  }

  if (input.reporter_contact) {
    const contactError = validateContact(input.reporter_contact);
    if (contactError) errors.push(contactError);
  }

  if (input.latitude != null) {
    const latError = validateLatitude(input.latitude);
    if (latError) errors.push(latError);
  }

  if (input.longitude != null) {
    const lngError = validateLongitude(input.longitude);
    if (lngError) errors.push(lngError);
  }

  // If one coordinate is set, both must be
  if ((input.latitude != null) !== (input.longitude != null)) {
    errors.push({
      field: 'coordinates',
      message: 'Both latitude and longitude are required when specifying a location.',
      message_te: 'స్థానాన్ని పేర్కొన్నప్పుడు అక్షాంశం మరియు రేఖాంశం రెండూ అవసరం.',
    });
  }

  return errors;
}

export function sanitizeText(input: string): string {
  return input
    .replace(/[<>]/g, '')
    .trim()
    .slice(0, MAX_DESCRIPTION_LENGTH);
}

export function sanitizeContact(input: string): string {
  return input
    .replace(/[<>]/g, '')
    .trim()
    .slice(0, MAX_CONTACT_LENGTH);
}

export function sanitizeLocationText(input: string): string {
  return input
    .replace(/[<>]/g, '')
    .trim()
    .slice(0, MAX_LOCATION_LENGTH);
}
