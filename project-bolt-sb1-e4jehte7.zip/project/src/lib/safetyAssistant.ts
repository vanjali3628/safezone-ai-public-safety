import type { Language, Severity } from '@/types';
import { SAFETY_TIPS, SEVERITY_LABELS } from '@/lib/constants';

export type AssistantResponse = {
  text: string;
  isEmergency: boolean;
  suggestedContacts: { name: string; phone: string }[];
};

const EMERGENCY_INDICATORS_EN = [
  'emergency', 'help', 'danger', 'fire', 'bleeding', 'unconscious',
  'not breathing', 'heart attack', 'stroke', 'accident', 'dying',
  'attack', 'threatened', 'assault', 'stabbed', 'shooting',
];

const EMERGENCY_INDICATORS_TE = [
  'అత్యవసర', 'సహాయం', 'ప్రమాదం', 'అగ్ని', 'రక్తం', 'స్పృహ లేదు',
  'శ్వాస లేదు', 'గుండె', 'పక్షవాతం', 'దాడి', 'ప్రాణాపాయం',
];

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  fire_hazard: ['fire', 'blaze', 'smoke', 'burning', 'flames', 'अग्नि', 'అగ్ని', 'పొగ'],
  waterlogging: ['flood', 'water', 'waterlogging', 'rain', 'వరద', 'నీరు', 'వర్షం'],
  crime: ['crime', 'theft', 'attack', 'assault', 'robbery', 'threat', 'నేర', 'దొంగ', 'దాడి', 'ముప్పు'],
  electrical: ['electric', 'shock', 'wire', 'power', 'electrocution', 'విద్యుత్', 'షాక్', 'వైర్'],
  road_hazard: ['road', 'pothole', 'accident', 'traffic', 'debris', 'రహదారి', 'గుంత', 'ట్రాఫిక్'],
};

const EMERGENCY_CONTACTS = [
  { name: 'Emergency (112)', phone: '112' },
  { name: 'Police (100)', phone: '100' },
  { name: 'Fire (101)', phone: '101' },
  { name: 'Ambulance (108)', phone: '108' },
];

export function generateSafetyResponse(
  userMessage: string,
  language: Language,
): AssistantResponse {
  const lower = userMessage.toLowerCase();
  const isTe = language === 'te';

  // Check for emergency indicators
  const emergencyKeywords = isTe ? EMERGENCY_INDICATORS_TE : EMERGENCY_INDICATORS_EN;
  const isEmergency = emergencyKeywords.some((kw) => lower.includes(kw.toLowerCase()));

  if (isEmergency) {
    return {
      text: isTe
        ? 'ఇది అత్యవసర పరిస్థితిగా అనిపిస్తుంది. వెంటనే 112 కు కాల్ చేయండి. ఈ యాప్ అత్యవసర సేవలను పంపదు — దయచేసి అధికారిక నంబర్‌లకు కాల్ చేయండి.'
        : 'This sounds like an emergency. Please call 112 immediately. This app does NOT dispatch emergency services — please call the official numbers below.',
      isEmergency: true,
      suggestedContacts: EMERGENCY_CONTACTS,
    };
  }

  // Find matching safety tip
  for (const [categoryCode, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some((kw) => lower.includes(kw.toLowerCase()))) {
      const tip = SAFETY_TIPS.find((t) => t.categoryCode === categoryCode);
      if (tip) {
        const steps = isTe ? tip.steps_te : tip.steps_en;
        const warning = isTe ? tip.warning_te : tip.warning_en;
        const title = isTe ? tip.title_te : tip.title_en;
        return {
          text: `${title}\n\n${steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\n⚠ ${warning}`,
          isEmergency: false,
          suggestedContacts: [{ name: 'Emergency (112)', phone: '112' }],
        };
      }
    }
  }

  // Default cautious response
  return {
    text: isTe
      ? 'నేను ఒక జాగ్రత్త భద్రతా సహాయకుడు. దయచేసి మీరు ఎదుర్కొంటున్న పరిస్థితిని వివరించండి — ఉదాహరణకు "అగ్ని ప్రమాదం", "రహదారి ప్రమాదం", "నీటి నిల్వ". అత్యవసరం అయితే, వెంటనే 112 కు కాల్ చేయండి.'
      : 'I am a cautious safety assistant. Please describe the situation you are facing — for example "fire hazard", "road hazard", or "waterlogging". If it is an emergency, please call 112 immediately.',
    isEmergency: false,
    suggestedContacts: [{ name: 'Emergency (112)', phone: '112' }],
  };
}

export function getSeverityRecommendation(severity: Severity, language: Language): string {
  const label = SEVERITY_LABELS[severity];
  const severityText = language === 'te' ? label.te : label.en;

  if (severity === 'critical' || severity === 'high') {
    return language === 'te'
      ? `ఈ ప్రమాదం "${severityText}" స్థాయిలో ఉంది. వెంటనే 112 కు కాల్ చేయండి మరియు ప్రాంతాన్ని ఖాళీ చేయండి.`
      : `This hazard is "${severityText}" severity. Call 112 immediately and evacuate the area.`;
  }

  return language === 'te'
    ? `ఈ ప్రమాదం "${severityText}" స్థాయిలో ఉంది. స్థానిక అధికారులకు నివేదించండి మరియు భద్రంగా ఉండండి.`
    : `This hazard is "${severityText}" severity. Report to local authorities and stay safe.`;
}
