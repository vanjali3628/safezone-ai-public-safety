import type { IncidentStatus, Severity, SafetyTip } from '@/types';

export const SEVERITY_LEVELS: Severity[] = ['low', 'medium', 'high', 'critical'];

export const SEVERITY_LABELS: Record<Severity, { en: string; te: string }> = {
  low: { en: 'Low', te: 'తక్కువ' },
  medium: { en: 'Medium', te: 'మధ్యమ' },
  high: { en: 'High', te: 'అధిక' },
  critical: { en: 'Critical', te: 'అత్యంత తీవ్ర' },
};

export const SEVERITY_COLORS: Record<Severity, {
  bg: string;
  text: string;
  border: string;
  dot: string;
}> = {
  low: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', dot: 'bg-emerald-500' },
  medium: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', dot: 'bg-amber-500' },
  high: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', dot: 'bg-orange-500' },
  critical: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', dot: 'bg-red-500' },
};

export const SEVERITY_ICONS: Record<Severity, string> = {
  low: 'Info',
  medium: 'AlertCircle',
  high: 'AlertTriangle',
  critical: 'Siren',
};

export const STATUS_ORDER: IncidentStatus[] = [
  'reported',
  'verified',
  'in_progress',
  'resolved',
  'rejected',
];

export const STATUS_LABELS: Record<IncidentStatus, { en: string; te: string }> = {
  reported: { en: 'Reported', te: 'నివేదించబడింది' },
  verified: { en: 'Verified', te: 'ధృవీకరించబడింది' },
  in_progress: { en: 'In Progress', te: 'పురోగతిలో' },
  resolved: { en: 'Resolved', te: 'పరిష్కరించబడింది' },
  rejected: { en: 'Rejected', te: 'తిరస్కరించబడింది' },
};

export const STATUS_COLORS: Record<IncidentStatus, {
  bg: string;
  text: string;
  border: string;
}> = {
  reported: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  verified: { bg: 'bg-cyan-50', text: 'text-cyan-700', border: 'border-cyan-200' },
  in_progress: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  resolved: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
  rejected: { bg: 'bg-gray-100', text: 'text-gray-600', border: 'border-gray-300' },
};

export const PAGE_SIZE = 10;

export const MAX_DESCRIPTION_LENGTH = 1000;
export const MIN_DESCRIPTION_LENGTH = 10;
export const MAX_LOCATION_LENGTH = 200;
export const MAX_CONTACT_LENGTH = 100;

export const RATE_LIMIT_WINDOW_MINUTES = 15;
export const RATE_LIMIT_MAX_REPORTS = 5;

export const TRACKING_CODE_PREFIX = 'SZ';
export const TRACKING_CODE_LENGTH = 8;

export const SAFETY_TIPS: SafetyTip[] = [
  {
    id: 'fire',
    categoryCode: 'fire_hazard',
    title_en: 'Fire Emergency',
    title_te: 'అగ్ని అత్యవసరం',
    steps_en: [
      'Call 101 (Fire Brigade) or 112 immediately.',
      'Alert everyone nearby and evacuate the area calmly.',
      'If smoke is present, stay low to the ground.',
      'Use the nearest exit — do not use elevators.',
      'If trapped, close doors between you and the fire and signal from a window.',
    ],
    steps_te: [
      '101 (అగ్నిమాపక విభాగం) లేదా 112 కు వెంటనే కాల్ చేయండి.',
      'దగ్గరలో ఉన్న ప్రతివారికీ తెలియజేసి, ప్రాంతాన్ని ప్రశాంతంగా ఖాళీ చేయండి.',
      'పొగ ఉంటే, నేలకు దగ్గరగా ఉండండి.',
      'సమీపంలోని నిష్క్రమణ మార్గాన్ని ఉపయోగించండి — లిఫ్టులు ఉపయోగించవద్దు.',
      'చిక్కుకు చిక్కితే, మీకు మరియు అగ్నికి మధ్య తలుపులు మూసి, కిటికీ నుండి సంకేతం ఇవ్వండి.',
    ],
    warning_en: 'Never attempt to fight a large fire yourself. Evacuate and call for help.',
    warning_te: 'పెద్ద అగ్నిని ఎప్పుడూ మీరే ఆపడానికి ప్రయత్నించవద్దు. ఖాళీ చేసి సహాయం పిలవండి.',
  },
  {
    id: 'flood',
    categoryCode: 'waterlogging',
    title_en: 'Flooding / Waterlogging',
    title_te: 'వరద / నీటి నిల్వ',
    steps_en: [
      'Move to higher ground immediately.',
      'Do not walk or drive through flooded areas — water depth is deceptive.',
      'Avoid contact with floodwater — it may be contaminated or hide hazards.',
      'Monitor local alerts and follow evacuation orders.',
      'Keep emergency supplies (water, food, flashlight, documents) ready.',
    ],
    steps_te: [
      'వెంటనే ఎత్తైన ప్రదేశానికి వెళ్లండి.',
      'మునిగిన ప్రాంతాలలో నడవడం లేదా వాహనం నడపడం చేయవద్దు — నీటి లోతు మోసపూరితం.',
      'వరద నీటితో సంబంధం నివారించండి — ఇది కలుషితం లేదా ప్రమాదాలను దాచి ఉండవచ్చు.',
      'స్థానిక హెచ్చరికలను గమనించండి మరియు ఖాళీ చేసే ఆదేశాలను పాటించండి.',
      'అత్యవసర సామాగ్రి (నీరు, ఆహారం, ఫ్లాష్‌లైట్, పత్రాలు) సిద్ధంగా ఉంచండి.',
    ],
    warning_en: '6 inches of moving water can knock you down. 2 feet can sweep a car away.',
    warning_te: '6 అంగుళాల కదులుతున్న నీరు మిమ్మల్ని కూలగొట్టగలదు. 2 అడుగులు కారును తీసుకుపోగలదు.',
  },
  {
    id: 'crime',
    categoryCode: 'crime',
    title_en: 'Crime / Personal Safety',
    title_te: 'నేరం / వ్యక్తిగత భద్రత',
    steps_en: [
      'Call 100 (Police) or 112 immediately if in danger.',
      'Move to a well-lit, populated area if possible.',
      'Do not confront the threat — prioritize your safety.',
      'Note details: appearance, clothing, vehicle number, direction.',
      'Women in distress can call 1091 for dedicated support.',
    ],
    steps_te: [
      'ప్రమాదంలో ఉంటే 100 (పోలీసు) లేదా 112 కు వెంటనే కాల్ చేయండి.',
      'సాధ్యమైతే బాగా వెలిగిన, జనావసరం ఉన్న ప్రదేశానికి వెళ్లండి.',
      'ముప్పును ఎదుర్కోవద్దు — మీ భద్రతకు ప్రాధాన్యత ఇవ్వండి.',
      'వివరాలు గుర్తించండి: రూపం, దుస్తులు, వాహన నంబర్, దిశ.',
      'మహిళలు 1091 కు కాల్ చేయవచ్చు.',
    ],
    warning_en: 'Do not attempt to apprehend criminals. Your safety is more important than property.',
    warning_te: 'నేరస్థులను పట్టుకోవడానికి ప్రయత్నించవద్దు. మీ భద్రత ఆస్తి కంటే ముఖ్యం.',
  },
  {
    id: 'electrical',
    categoryCode: 'electrical',
    title_en: 'Electrical Hazard',
    title_te: 'విద్యుత్ ప్రమాదం',
    steps_en: [
      'Do not touch the source or anything in contact with it.',
      'Call 112 and report the hazard. Keep others away.',
      'If someone is shocked, turn off power at the main switch if safe.',
      'Do not attempt rescue until power is confirmed off.',
      'Report fallen power lines to authorities immediately.',
    ],
    steps_te: [
      'మూలాన్ని లేదా దానితో సంబంధం ఉన్న దేనినీ తాకవద్దు.',
      '112 కు కాల్ చేసి ప్రమాదాన్ని నివేదించండి. ఇతరులను దూరంగా ఉంచండి.',
      'ఎవరైనా షాక్ అయితే, సురక్షితమైతే మెయిన్ స్విచ్ వద్ద విద్యుత్ ఆపండి.',
      'విద్యుత్ ఆపివేయబడిందని నిర్ధారణ అయ్యే వరకు రక్షణ ప్రయత్నించవద్దు.',
      'పడిపోయిన విద్యుత్ లైన్‌లను అధికారులకు వెంటనే నివేదించండి.',
    ],
    warning_en: 'Never touch someone being electrocuted — you will be shocked too. Cut power first.',
    warning_te: 'ఎలక్ట్రోక్యూట్ అవుతున్న వ్యక్తిని ఎప్పుడూ తాకవద్దు — మీకు కూడా షాక్ వస్తుంది. ముందు విద్యుత్ ఆపండి.',
  },
  {
    id: 'road',
    categoryCode: 'road_hazard',
    title_en: 'Road Hazard',
    title_te: 'రహదారి ప్రమాదం',
    steps_en: [
      'Slow down and warn other drivers with hazard lights.',
      'Do not drive over debris or damaged road sections.',
      'Report potholes, debris, or damage to local authorities.',
      'If injured, call 108 for ambulance services.',
      'Take alternate routes if a road is blocked or flooded.',
    ],
    steps_te: [
      'వేగాన్ని తగ్గించి, హజార్డ్ లైట్‌లతో ఇతర డ్రైవర్‌లకు హెచ్చరించండి.',
      'శిథిలాలు లేదా దెబ్బతిన్న రహదారి భాగాలపై వాహనం నడపవద్దు.',
      'గుంతలు, శిథిలాలు లేదా నష్టాన్ని స్థానిక అధికారులకు నివేదించండి.',
      'గాయపడితే, 108 కు కాల్ చేయండి.',
      'రహదారి అడ్డగించబడితే ప్రత్యామ్నాయ మార్గాలు తీసుకోండి.',
    ],
    warning_en: 'Do not stop on highways to inspect hazards. Pull over safely first.',
    warning_te: 'ప్రమాదాలను తనిఖీ చేయడానికి హైవేలపై ఆగవద్దు. ముందు సురక్షితంగా ఆగండి.',
  },
  {
    id: 'general',
    categoryCode: 'other',
    title_en: 'General Emergency',
    title_te: 'సాధారణ అత్యవసరం',
    steps_en: [
      'Call 112 for any emergency — police, fire, or medical.',
      'Stay calm and speak clearly when reporting.',
      'Provide your exact location and nature of the emergency.',
      'Do not hang up until the operator tells you to.',
      'If safe, stay at the scene to guide responders.',
    ],
    steps_te: [
      'ఏ అత్యవసరం కోసం అయినా 112 కు కాల్ చేయండి.',
      'ప్రశాంతంగా ఉండి, స్పష్టంగా మాట్లాడండి.',
      'మీ సరైన స్థానం మరియు అత్యవసర స్వభావాన్ని చెప్పండి.',
      'ఆపరేటర్ చెప్పే వరకు ఫోన్ పెట్టవద్దు.',
      'సురక్షితమైతే, రెస్పాండర్‌లను మార్గనిర్దేశం చేయడానికి స్థలంలో ఉండండి.',
    ],
    warning_en: 'This app does NOT replace emergency services. Always call official numbers for real emergencies.',
    warning_te: 'ఈ యాప్ అత్యవసర సేవలను భర్తీ చేయదు. నిజమైన అత్యవసరాల కోసం ఎల్లప్పుడూ అధికారిక నంబర్‌లకు కాల్ చేయండి.',
  },
];

export const DISCLAIMER_EN =
  'SafeZone AI is a community safety platform. Community reports are NOT automatically verified and do not replace emergency services. For emergencies, always call 112.';

export const DISCLAIMER_TE =
  'SafeZone AI ఒక కమ్యూనిటీ భద్రతా వేదిక. కమ్యూనిటీ నివేదికలు స్వయంచాలకంగా ధృవీకరించబడవు మరియు అత్యవసర సేవలను భర్తీ చేయవు. అత్యవసరాల కోసం ఎల్లప్పుడూ 112 కు కాల్ చేయండి.';

export const SAFETY_ASSISTANT_SYSTEM_PROMPT_EN =
  'You are a cautious public safety assistant for Indian citizens, primarily in Telugu-speaking regions. ' +
  'Provide practical, safe guidance. ALWAYS prioritize calling official emergency numbers (112, 100, 101, 108). ' +
  'Never give medical diagnoses or legal advice. Never claim to dispatch emergency services. ' +
  'If a situation sounds life-threatening, immediately advise calling 112. ' +
  'Keep responses concise and actionable.';

export const SAFETY_ASSISTANT_SYSTEM_PROMPT_TE =
  'మీరు భారతీయ పౌరుల కోసం జాగ్రత్త ప్రజా భద్రతా సహాయకుడు. ' +
  'ఆచరణీయ, సురక్షిత మార్గదర్శకత్వం ఇవ్వండి. ఎల్లప్పుడూ అధికారిక అత్యవసర నంబర్‌లకు కాల్ చేయమని సూచించండి (112, 100, 101, 108). ' +
  'వైద్య రోగనిర్ధారణలు లేదా న్యాయ సలహా ఇవ్వవద్దు. అత్యవసర సేవలను పంపుతున్నట్లు ఎప్పుడూ చెప్పవద్దు.';
