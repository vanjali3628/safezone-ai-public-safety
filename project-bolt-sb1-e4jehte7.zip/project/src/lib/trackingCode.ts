import { TRACKING_CODE_PREFIX, TRACKING_CODE_LENGTH } from '@/lib/constants';

const CHARSET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function generateTrackingCode(): string {
  const chars: string[] = [];
  for (let i = 0; i < TRACKING_CODE_LENGTH; i++) {
    const idx = Math.floor(Math.random() * CHARSET.length);
    chars.push(CHARSET[idx]);
  }
  return `${TRACKING_CODE_PREFIX}-${chars.join('')}`;
}

export function isValidTrackingCode(code: string): boolean {
  const pattern = new RegExp(`^${TRACKING_CODE_PREFIX}-[A-Z2-9]{${TRACKING_CODE_LENGTH}}$`);
  return pattern.test(code.trim().toUpperCase());
}

export function normalizeTrackingCode(code: string): string {
  return code.trim().toUpperCase();
}
