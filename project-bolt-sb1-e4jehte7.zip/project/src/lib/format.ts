export function formatRelativeTime(isoDate: string, lang: 'en' | 'te' = 'en'): string {
  const date = new Date(isoDate);
  const now = Date.now();
  const diffMs = now - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);

  if (lang === 'te') {
    if (diffSec < 60) return 'ఇప్పుడే';
    if (diffMin < 60) return `${diffMin} నిమిషాల క్రితం`;
    if (diffHour < 24) return `${diffHour} గంటల క్రితం`;
    if (diffDay < 7) return `${diffDay} రోజుల క్రితం`;
    return date.toLocaleDateString('te-IN');
  }

  if (diffSec < 60) return 'just now';
  if (diffMin < 60) return `${diffMin} minutes ago`;
  if (diffHour < 24) return `${diffHour} hours ago`;
  if (diffDay < 7) return `${diffDay} days ago`;
  return date.toLocaleDateString('en-IN');
}

export function formatDateTime(isoDate: string, lang: 'en' | 'te' = 'en'): string {
  const date = new Date(isoDate);
  const locale = lang === 'te' ? 'te-IN' : 'en-IN';
  return date.toLocaleString(locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'string') return error;
  return 'An unexpected error occurred';
}
