/*
# Create SafeZone AI incident reporting schema

## Purpose
This schema supports a public safety incident reporting platform where citizens
can report hazards, track their status, and access safety guidance. The app
supports English and Telugu languages.

## New Tables

### 1. incident_categories
- Lookup table for hazard categories (e.g., road hazard, waterlogging, crime, fire hazard).
- `id` (serial, primary key)
- `code` (text, unique) — machine-readable code like "road_hazard"
- `label_en` (text) — English label
- `label_te` (text) — Telugu label
- `default_severity` (text) — default severity level: low, medium, high, critical
- `icon` (text) — lucide icon name for UI
- `sort_order` (int) — display ordering

### 2. incidents
- Core table for reported hazards.
- `id` (uuid, primary key)
- `tracking_code` (text, unique) — a random code the reporter uses to look up their report privately (e.g., "SZ-A8F3K2"). This replaces collecting personal data.
- `category_id` (int, references incident_categories)
- `description` (text, NOT NULL) — what the hazard is, sanitized
- `latitude` (numeric, nullable) — location coords
- `longitude` (numeric, nullable) — location coords
- `location_text` (text, nullable) — human-readable location description
- `severity` (text, NOT NULL, default 'medium') — low | medium | high | critical
- `status` (text, NOT NULL, default 'reported') — reported | verified | in_progress | resolved | rejected
- `reporter_contact` (text, nullable) — optional contact, never shown publicly
- `image_url` (text, nullable) — optional photo URL (stored in Supabase Storage)
- `is_public` (boolean, default true) — whether the incident appears on the public map
- `created_at` (timestamptz, default now())
- `updated_at` (timestamptz, default now())
- `resolved_at` (timestamptz, nullable)

### 3. incident_events
- Audit trail for status changes on incidents.
- `id` (uuid, primary key)
- `incident_id` (uuid, references incidents ON DELETE CASCADE)
- `event_type` (text, NOT NULL) — created | status_changed | verified | resolved | rejected
- `old_status` (text, nullable)
- `new_status` (text, nullable)
- `note` (text, nullable)
- `created_by` (uuid, nullable) — auth user id if changed by a moderator
- `created_at` (timestamptz, default now())

### 4. report_rate_limits
- Rate limiting table to prevent abuse of the incident reporting endpoint.
- `id` (uuid, primary key)
- `identifier` (text, NOT NULL) — IP address or hashed identifier
- `action` (text, NOT NULL) — e.g. "report_incident"
- `created_at` (timestamptz, default now())

### 5. emergency_contacts
- Verified emergency contact information for Indian/Telugu states.
- `id` (serial, primary key)
- `name_en` (text, NOT NULL)
- `name_te` (text, NOT NULL)
- `phone` (text, NOT NULL)
- `description_en` (text, nullable)
- `description_te` (text, nullable)
- `category` (text, NOT NULL) — police | fire | ambulance | women_helpline | disaster | general
- `sort_order` (int, default 0)

## Security
- RLS enabled on ALL tables.
- incidents: public SELECT only for is_public=true rows (no reporter_contact exposed).
  INSERT allowed for anon (citizens can report without signing in).
  UPDATE/DELETE only for authenticated moderators.
- incident_events: SELECT allowed for anon (audit trail is public).
  INSERT allowed for anon only on "created" events; authenticated moderators can insert status changes.
- incident_categories, emergency_contacts: fully public read, no writes from anon.
- report_rate_limits: no public access (used by edge function with service role).

## Indexes
- incidents(status), incidents(category_id), incidents(created_at)
- incident_events(incident_id)
- report_rate_limits(identifier, action, created_at)
- incidents(tracking_code) unique index
*/

-- Incident categories lookup table
CREATE TABLE IF NOT EXISTS incident_categories (
  id serial PRIMARY KEY,
  code text UNIQUE NOT NULL,
  label_en text NOT NULL,
  label_te text NOT NULL,
  default_severity text NOT NULL DEFAULT 'medium' CHECK (default_severity IN ('low', 'medium', 'high', 'critical')),
  icon text NOT NULL DEFAULT 'AlertTriangle',
  sort_order int NOT NULL DEFAULT 0
);

-- Core incidents table
CREATE TABLE IF NOT EXISTS incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_code text UNIQUE NOT NULL,
  category_id int NOT NULL REFERENCES incident_categories(id),
  description text NOT NULL,
  latitude numeric(10,7),
  longitude numeric(10,7),
  location_text text,
  severity text NOT NULL DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  status text NOT NULL DEFAULT 'reported' CHECK (status IN ('reported', 'verified', 'in_progress', 'resolved', 'rejected')),
  reporter_contact text,
  image_url text,
  is_public boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

-- Audit trail for status changes
CREATE TABLE IF NOT EXISTS incident_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id uuid NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('created', 'status_changed', 'verified', 'resolved', 'rejected')),
  old_status text,
  new_status text,
  note text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Rate limiting table
CREATE TABLE IF NOT EXISTS report_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier text NOT NULL,
  action text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Emergency contacts
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id serial PRIMARY KEY,
  name_en text NOT NULL,
  name_te text NOT NULL,
  phone text NOT NULL,
  description_en text,
  description_te text,
  category text NOT NULL CHECK (category IN ('police', 'fire', 'ambulance', 'women_helpline', 'disaster', 'general')),
  sort_order int NOT NULL DEFAULT 0
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
CREATE INDEX IF NOT EXISTS idx_incidents_category ON incidents(category_id);
CREATE INDEX IF NOT EXISTS idx_incidents_created ON incidents(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_incidents_public ON incidents(is_public) WHERE is_public = true;
CREATE INDEX IF NOT EXISTS idx_incident_events_incident ON incident_events(incident_id);
CREATE INDEX IF NOT EXISTS idx_rate_limits_lookup ON report_rate_limits(identifier, action, created_at DESC);

-- Enable RLS on all tables
ALTER TABLE incident_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE incident_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;

-- ========== incident_categories policies (public read, no anon writes) ==========
DROP POLICY IF EXISTS "public_read_categories" ON incident_categories;
CREATE POLICY "public_read_categories" ON incident_categories FOR SELECT
  TO anon, authenticated USING (true);

-- ========== emergency_contacts policies (public read, no anon writes) ==========
DROP POLICY IF EXISTS "public_read_contacts" ON emergency_contacts;
CREATE POLICY "public_read_contacts" ON emergency_contacts FOR SELECT
  TO anon, authenticated USING (true);

-- ========== incidents policies ==========
-- Public can see only public incidents (and reporter_contact is NOT selected in queries)
DROP POLICY IF EXISTS "public_read_incidents" ON incidents;
CREATE POLICY "public_read_incidents" ON incidents FOR SELECT
  TO anon, authenticated USING (is_public = true);

-- Authenticated moderators can see all incidents including private
DROP POLICY IF EXISTS "mod_read_all_incidents" ON incidents;
CREATE POLICY "mod_read_all_incidents" ON incidents FOR SELECT
  TO authenticated USING (true);

-- Anyone (anon) can create incident reports
DROP POLICY IF EXISTS "anon_insert_incidents" ON incidents;
CREATE POLICY "anon_insert_incidents" ON incidents FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Only authenticated moderators can update incidents (status changes)
DROP POLICY IF EXISTS "mod_update_incidents" ON incidents;
CREATE POLICY "mod_update_incidents" ON incidents FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- Only authenticated moderators can delete incidents
DROP POLICY IF EXISTS "mod_delete_incidents" ON incidents;
CREATE POLICY "mod_delete_incidents" ON incidents FOR DELETE
  TO authenticated USING (true);

-- ========== incident_events policies ==========
-- Public can read audit trail
DROP POLICY IF EXISTS "public_read_events" ON incident_events;
CREATE POLICY "public_read_events" ON incident_events FOR SELECT
  TO anon, authenticated USING (true);

-- Anyone can insert "created" events (when a new incident is reported)
DROP POLICY IF EXISTS "anon_insert_events" ON incident_events;
CREATE POLICY "anon_insert_events" ON incident_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Only authenticated moderators can update/delete events
DROP POLICY IF EXISTS "mod_update_events" ON incident_events;
CREATE POLICY "mod_update_events" ON incident_events FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "mod_delete_events" ON incident_events;
CREATE POLICY "mod_delete_events" ON incident_events FOR DELETE
  TO authenticated USING (true);

-- ========== report_rate_limits policies (no public access) ==========
-- Only authenticated (edge function uses service role which bypasses RLS)
DROP POLICY IF EXISTS "auth_manage_rate_limits" ON report_rate_limits;
CREATE POLICY "auth_manage_rate_limits" ON report_rate_limits FOR ALL
  TO authenticated USING (true) WITH CHECK (true);

-- ========== Seed data: incident categories ==========
INSERT INTO incident_categories (code, label_en, label_te, default_severity, icon, sort_order) VALUES
  ('road_hazard', 'Road Hazard', 'రహదారి ప్రమాదం', 'medium', 'Construction', 1),
  ('waterlogging', 'Waterlogging / Flood', 'నీటి నిల్వ / వరద', 'high', 'Waves', 2),
  ('fire_hazard', 'Fire Hazard', 'అగ్ని ప్రమాదం', 'critical', 'Flame', 3),
  ('crime', 'Crime / Safety Threat', 'నేరం / భద్రతా ముప్పు', 'high', 'ShieldAlert', 4),
  ('electrical', 'Electrical Hazard', 'విద్యుత్ ప్రమాదం', 'high', 'Zap', 5),
  ('sanitation', 'Sanitation / Health', 'పారిశుద్య / ఆరోగ్య', 'medium', 'Biohazard', 6),
  ('infrastructure', 'Infrastructure Damage', 'మౌలిక సదుపాయ నష్టం', 'medium', 'Building2', 7),
  ('animal_threat', 'Stray Animal Threat', 'స్ట్రే జంతు ముప్పు', 'low', 'Dog', 8),
  ('other', 'Other Hazard', 'ఇతర ప్రమాదం', 'low', 'AlertTriangle', 9)
ON CONFLICT (code) DO NOTHING;

-- ========== Seed data: emergency contacts (Indian emergency numbers) ==========
INSERT INTO emergency_contacts (name_en, name_te, phone, description_en, description_te, category, sort_order) VALUES
  ('National Emergency Number', 'జాతీయ అత్యవసర నంబర్', '112', 'Single emergency number for police, fire, and ambulance', 'పోలీసు, అగ్నిమాపక, అంబులెన్స్ కోసం ఒకే అత్యవసర నంబర్', 'general', 1),
  ('Police', 'పోలీసు', '100', 'Police emergency helpline', 'పోలీసు అత్యవసర సహాయ నంబర్', 'police', 2),
  ('Fire Brigade', 'అగ్నిమాపక విభాగం', '101', 'Fire emergency services', 'అగ్ని అత్యవసర సేవలు', 'fire', 3),
  ('Ambulance', 'అంబులెన్స్', '108', 'Emergency medical services and ambulance', 'అత్యవసర వైద్య సేవలు మరియు అంబులెన్స్', 'ambulance', 4),
  ('Women Helpline', 'మహిళల హెల్ప్‌లైన్', '1091', '24x7 helpline for women in distress', 'మహిళల సహాయ నంబర్ - 24 గంటల సేవ', 'women_helpline', 5),
  ('Child Helpline', 'పిల్లల హెల్ప్‌లైన్', '1098', '24x7 helpline for children in need', 'పిల్లల సహాయ నంబర్ - 24 గంటల సేవ', 'general', 6),
  ('Disaster Management (NDMA)', 'విపత్తు నిర్వాహణ (NDMA)', '1078', 'National Disaster Management helpline', 'జాతీయ విపత్తు నిర్వాహణ సహాయ నంబర్', 'disaster', 7),
  ('Cyber Crime Helpline', 'సైబర్ నేర హెల్ప్‌లైన్', '1930', 'Report cyber crime and online fraud', 'సైబర్ నేర మరియు ఆన్‌లైన్ మోసం నివేదించండి', 'general', 8),
  ('Railway Helpline', 'రైల్వే హెల్ప్‌లైన్', '139', 'Railway emergency and assistance', 'రైల్వే అత్యవసర సహాయ', 'general', 9)
ON CONFLICT DO NOTHING;